# Placement and Career Analytics using R Programming

A modern, responsive academic dashboard designed for final-year college projects. It provides institutional placement tracking, statistical career analytics, and machine learning placement probability estimation calibrated with R programming models.

---

## 🚀 Free Public Deployment Options (No Google Cloud Billing)

This web application is built as a pure client-side Single Page Application (SPA). All statistical calculations, logistic regression odds ratios, Chart.js visualizations, and report generations run in the browser. You do **not** need a paid server, database, or Google Cloud billing account.

### Option 1: AI Studio Pre-Shared Public URL (Instant, No Setup)
AI Studio automatically provisions a public URL for your project:
- **Shared Live URL**: `https://ais-pre-7skkgzyf4awm554m6swk7c-347780344000.asia-east1.run.app`
- Anyone can access this URL without logging into Google Cloud.

---

### Option 2: GitHub Pages (100% Free, Permanent, Custom Subdomain)
1. Create a free account on [GitHub](https://github.com) if you do not have one.
2. Create a new public repository (e.g. `placement-analytics-r`).
3. Push or upload all files from this project into your GitHub repository.
4. Go to **Settings** > **Pages** in your repository.
5. Under **Build and deployment** > **Source**, select **GitHub Actions**.
6. The automated workflow in `.github/workflows/deploy.yml` will automatically build the app and publish it to:
   `https://<your-username>.github.io/<repository-name>/`
7. It updates automatically whenever you push code changes.

---

### Option 3: Vercel (Instant Deploy, 100% Free)
1. Go to [Vercel.com](https://vercel.com) and sign up with GitHub.
2. Click **Add New...** > **Project**.
3. Import your GitHub repository.
4. Framework Preset will automatically detect **Vite**.
5. Click **Deploy**. Your app will be live at `https://<your-app>.vercel.app` in under 60 seconds.

---

### Option 4: Netlify (Drag-and-Drop or Git, 100% Free)
1. Run `npm run build` locally in your project folder to generate the `dist/` directory.
2. Sign in to [Netlify.com](https://www.netlify.com).
3. Under **Sites**, drag and drop your `dist/` folder onto the Netlify dashboard.
4. Netlify will instantly provide a public HTTPS URL (e.g., `https://placement-analytics.netlify.app`).

---

## 📦 Project File Structure

```text
├── index.html                   # HTML entry point with metadata & web fonts
├── package.json                 # Project dependencies & scripts
├── tsconfig.json                # TypeScript compiler configuration
├── vite.config.ts               # Vite configuration with relative base './'
├── .github/workflows/
│   └── deploy.yml               # Automated GitHub Pages CI/CD workflow
└── src/
    ├── main.tsx                 # React DOM mount point
    ├── App.tsx                  # Root application router and modal controllers
    ├── index.css                # Tailwind CSS styling and print media rules
    ├── types/
    │   └── index.ts             # TypeScript definitions for students & models
    ├── data/
    │   ├── studentsData.ts      # 55 realistic student placement records
    │   └── rScriptsData.ts      # Full R scripts (EDA, ggplot2, caret, plumber)
    ├── services/
    │   ├── rAnalyticsService.ts # R statistical computing engine & logistic regression
    │   └── careerRecommendationService.ts # Skill gap and career path benchmark engine
    ├── components/
    │   ├── Sidebar.tsx          # Responsive navigation menu
    │   ├── Header.tsx           # Top navigation bar with action buttons
    │   ├── StatCard.tsx         # KPI metrics card
    │   ├── StudentModal.tsx     # Add/edit candidate modal with validation
    │   ├── DeleteConfirmModal.tsx # Safe deletion prompt
    │   ├── RCodeModal.tsx       # R script inspection and download modal
    │   └── RConsoleSimulator.tsx# Interactive in-browser R terminal sandbox
    └── pages/
        ├── HomePage.tsx         # Project title, intro, and KPI summary
        ├── DashboardPage.tsx    # Conversion rates, salaries, and company charts
        ├── StudentDataPage.tsx  # Searchable registry with filters and CSV export
        ├── PlacementAnalyticsPage.tsx # Sigmoid curve, correlations, and distributions
        ├── CareerAnalyticsPage.tsx    # Personalized career pathways and skill gaps
        ├── PlacementPredictionPage.tsx# ML logistic regression predictor
        ├── ReportsPage.tsx      # Formal academic placement report with print layout
        └── AboutProjectPage.tsx # Methodology, packages, and R execution guide
```

---

## 💻 Local Execution Instructions

```bash
# 1. Install Node.js dependencies
npm install

# 2. Run local development server
npm run dev

# 3. Create production static build (creates /dist folder)
npm run build
```
