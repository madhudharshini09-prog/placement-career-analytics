export type Department = 
  | 'Computer Science'
  | 'Information Technology'
  | 'Electronics & Comm'
  | 'Mechanical Engineering'
  | 'Electrical Engineering'
  | 'Civil Engineering';

export type PlacementStatus = 'Placed' | 'Not Placed';

export interface Student {
  id: string;
  name: string;
  department: Department;
  cgpa: number;
  technicalSkills: string[];
  aptitudeScore: number;       // out of 100
  communicationScore: number;  // out of 100
  internshipExperience: number; // in months
  placementStatus: PlacementStatus;
  companyName: string;         // '-' if not placed
  salaryPackage: number;       // in LPA (0 if not placed)
  gender: 'Male' | 'Female';
  academicYear: string;
}

export interface SummaryStats {
  totalStudents: number;
  placedStudents: number;
  unplacedStudents: number;
  placementRate: number;      // percentage
  avgSalary: number;          // LPA
  medianSalary: number;       // LPA
  highestSalary: number;      // LPA
  lowestSalary: number;       // LPA for placed
  salaryStdDev: number;
  avgCgpa: number;
  avgAptitude: number;
  avgCommunication: number;
}

export interface DepartmentStat {
  department: Department;
  total: number;
  placed: number;
  unplaced: number;
  placementRate: number;
  avgCgpa: number;
  avgPackage: number;
  highestPackage: number;
}

export interface CompanyStat {
  company: string;
  count: number;
  avgPackage: number;
  highestPackage: number;
  tier: 'Tier 1 / Product' | 'IT Services' | 'Consulting / Analytics' | 'Core Engineering';
}

export interface PredictionInput {
  cgpa: number;
  aptitudeScore: number;
  communicationScore: number;
  internshipExperience: number;
  technicalSkills: string[];
  department?: Department;
}

export interface PredictionResult {
  probability: number;            // 0 - 100%
  status: 'High Likelihood' | 'Moderate Likelihood' | 'At-Risk / Needs Preparation';
  confidenceInterval: [number, number]; // [lower, upper]
  oddsRatio: number;
  factors: {
    name: string;
    impact: 'positive' | 'negative' | 'neutral';
    weight: number;
    description: string;
  }[];
  rFormulaString: string;
  recommendations: string[];
}

export interface CareerPathRecommendation {
  roleTitle: string;
  matchScore: number; // percentage
  suitability: 'High' | 'Medium' | 'Low';
  requiredSkills: string[];
  matchingSkills: string[];
  missingSkills: string[];
  averageEntryLPA: string;
  actionPlan: string[];
}
