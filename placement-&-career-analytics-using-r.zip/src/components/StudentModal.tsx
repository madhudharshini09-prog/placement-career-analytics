import React, { useState, useEffect } from 'react';
import { X, Check, AlertCircle } from 'lucide-react';
import { AVAILABLE_SKILLS, DEPARTMENTS } from '../data/studentsData';
import { Department, PlacementStatus, Student } from '../types';

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (student: Student) => void;
  initialData?: Student | null;
}

export const StudentModal: React.FC<StudentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData
}) => {
  const isEditing = !!initialData;

  const [formData, setFormData] = useState<Partial<Student>>({
    id: '',
    name: '',
    department: 'Computer Science',
    cgpa: 8.0,
    technicalSkills: ['Python', 'SQL'],
    aptitudeScore: 75,
    communicationScore: 75,
    internshipExperience: 2,
    placementStatus: 'Placed',
    companyName: 'TCS Digital',
    salaryPackage: 7.5,
    gender: 'Male',
    academicYear: '2024-2025'
  });

  const [customSkillInput, setCustomSkillInput] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      const generatedId = `STU2025${Math.floor(100 + Math.random() * 900)}`;
      setFormData({
        id: generatedId,
        name: '',
        department: 'Computer Science',
        cgpa: 8.2,
        technicalSkills: ['Python', 'SQL', 'Data Structures'],
        aptitudeScore: 80,
        communicationScore: 78,
        internshipExperience: 2,
        placementStatus: 'Placed',
        companyName: '',
        salaryPackage: 6.5,
        gender: 'Male',
        academicYear: '2024-2025'
      });
    }
    setErrors({});
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name?.trim()) {
      newErrors.name = 'Student Name is required.';
    }
    if (formData.cgpa === undefined || formData.cgpa < 0 || formData.cgpa > 10) {
      newErrors.cgpa = 'CGPA must be between 0.0 and 10.0.';
    }
    if (formData.aptitudeScore === undefined || formData.aptitudeScore < 0 || formData.aptitudeScore > 100) {
      newErrors.aptitudeScore = 'Aptitude score must be between 0 and 100.';
    }
    if (formData.communicationScore === undefined || formData.communicationScore < 0 || formData.communicationScore > 100) {
      newErrors.communicationScore = 'Communication score must be between 0 and 100.';
    }
    if (formData.internshipExperience === undefined || formData.internshipExperience < 0) {
      newErrors.internshipExperience = 'Internship experience cannot be negative.';
    }
    if (formData.placementStatus === 'Placed') {
      if (!formData.companyName?.trim() || formData.companyName === '-') {
        newErrors.companyName = 'Company name is required for placed candidates.';
      }
      if (formData.salaryPackage === undefined || formData.salaryPackage <= 0) {
        newErrors.salaryPackage = 'Salary package must be greater than 0 for placed candidates.';
      }
    }
    if (!formData.technicalSkills || formData.technicalSkills.length === 0) {
      newErrors.technicalSkills = 'Please select or add at least one technical skill.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const studentToSave: Student = {
      id: formData.id || `STU2025${Math.floor(100 + Math.random() * 900)}`,
      name: formData.name!.trim(),
      department: (formData.department as Department) || 'Computer Science',
      cgpa: Number(Number(formData.cgpa).toFixed(2)),
      technicalSkills: formData.technicalSkills || [],
      aptitudeScore: Number(formData.aptitudeScore),
      communicationScore: Number(formData.communicationScore),
      internshipExperience: Number(formData.internshipExperience),
      placementStatus: (formData.placementStatus as PlacementStatus) || 'Placed',
      companyName: formData.placementStatus === 'Placed' ? (formData.companyName?.trim() || 'Hired') : '-',
      salaryPackage: formData.placementStatus === 'Placed' ? Number(Number(formData.salaryPackage).toFixed(1)) : 0,
      gender: formData.gender as 'Male' | 'Female' || 'Male',
      academicYear: formData.academicYear || '2024-2025'
    };

    onSave(studentToSave);
  };

  const toggleSkill = (skill: string) => {
    const current = formData.technicalSkills || [];
    if (current.includes(skill)) {
      setFormData({ ...formData, technicalSkills: current.filter(s => s !== skill) });
    } else {
      setFormData({ ...formData, technicalSkills: [...current, skill] });
    }
  };

  const handleAddCustomSkill = () => {
    if (!customSkillInput.trim()) return;
    const current = formData.technicalSkills || [];
    if (!current.includes(customSkillInput.trim())) {
      setFormData({ ...formData, technicalSkills: [...current, customSkillInput.trim()] });
    }
    setCustomSkillInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl border border-slate-200 overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div>
            <h3 className="font-bold text-slate-900 text-lg">
              {isEditing ? 'Edit Student Placement Record' : 'Add New Student Placement Record'}
            </h3>
            <p className="text-xs text-slate-500">
              {isEditing ? `Modifying profile for ${formData.id}` : 'Enter academic scores, skills, and placement outcome'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Row 1: ID & Name */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Student ID
              </label>
              <input
                type="text"
                value={formData.id || ''}
                onChange={e => setFormData({ ...formData, id: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg font-mono focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                placeholder="STU2025001"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Student Full Name *
              </label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className={`w-full px-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden ${
                  errors.name ? 'border-rose-400 bg-rose-50/30' : 'border-slate-200'
                }`}
                placeholder="e.g. Priyanshu Sharma"
              />
              {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>}
            </div>
          </div>

          {/* Row 2: Department & Gender & Year */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Department
              </label>
              <select
                value={formData.department}
                onChange={e => setFormData({ ...formData, department: e.target.value as Department })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              >
                {DEPARTMENTS.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Gender
              </label>
              <select
                value={formData.gender}
                onChange={e => setFormData({ ...formData, gender: e.target.value as 'Male' | 'Female' })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Academic Year
              </label>
              <select
                value={formData.academicYear}
                onChange={e => setFormData({ ...formData, academicYear: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              >
                <option value="2024-2025">2024-2025</option>
                <option value="2023-2024">2023-2024</option>
              </select>
            </div>
          </div>

          {/* Row 3: Quantitative Academic Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                CGPA (0 - 10) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                max="10"
                value={formData.cgpa ?? ''}
                onChange={e => setFormData({ ...formData, cgpa: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
              {errors.cgpa && <p className="text-[10px] text-rose-500 mt-0.5">{errors.cgpa}</p>}
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Aptitude (0-100) *
              </label>
              <input
                type="number"
                min="0"
                max="100"
                value={formData.aptitudeScore ?? ''}
                onChange={e => setFormData({ ...formData, aptitudeScore: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
              {errors.aptitudeScore && <p className="text-[10px] text-rose-500 mt-0.5">{errors.aptitudeScore}</p>}
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Comm. Score (0-100) *
              </label>
              <input
                type="number"
                min="0"
                max="100"
                value={formData.communicationScore ?? ''}
                onChange={e => setFormData({ ...formData, communicationScore: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
              {errors.communicationScore && <p className="text-[10px] text-rose-500 mt-0.5">{errors.communicationScore}</p>}
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Internships (Mo)
              </label>
              <input
                type="number"
                min="0"
                max="24"
                value={formData.internshipExperience ?? ''}
                onChange={e => setFormData({ ...formData, internshipExperience: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Row 4: Placement Outcome */}
          <div className="p-4 bg-slate-50/70 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                Campus Placement Outcome
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, placementStatus: 'Placed' })}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    formData.placementStatus === 'Placed'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  Placed
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, placementStatus: 'Not Placed', companyName: '-', salaryPackage: 0 })}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    formData.placementStatus === 'Not Placed'
                      ? 'bg-slate-700 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  Not Placed
                </button>
              </div>
            </div>

            {formData.placementStatus === 'Placed' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Recruiting Company *
                  </label>
                  <input
                    type="text"
                    value={formData.companyName || ''}
                    onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    placeholder="e.g. Microsoft, TCS Digital, Amazon"
                  />
                  {errors.companyName && <p className="text-[10px] text-rose-500 mt-0.5">{errors.companyName}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Salary Package (LPA) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    value={formData.salaryPackage || ''}
                    onChange={e => setFormData({ ...formData, salaryPackage: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                    placeholder="e.g. 12.5"
                  />
                  {errors.salaryPackage && <p className="text-[10px] text-rose-500 mt-0.5">{errors.salaryPackage}</p>}
                </div>
              </div>
            )}
          </div>

          {/* Row 5: Technical Skills Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Technical Skill Stack (Select or add skills)
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2 max-h-28 overflow-y-auto p-2 bg-slate-50 border border-slate-200 rounded-lg">
              {AVAILABLE_SKILLS.map(skill => {
                const selected = formData.technicalSkills?.includes(skill);
                return (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => toggleSkill(skill)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                      selected
                        ? 'bg-blue-600 text-white font-semibold shadow-2xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {skill} {selected && '✓'}
                  </button>
                );
              })}
            </div>

            {/* Custom skill adder */}
            <div className="flex gap-2">
              <input
                type="text"
                value={customSkillInput}
                onChange={e => setCustomSkillInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCustomSkill();
                  }
                }}
                className="flex-1 px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                placeholder="Add other skill (e.g. Rust, PyTorch, GraphQL)..."
              />
              <button
                type="button"
                onClick={handleAddCustomSkill}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Add Skill
              </button>
            </div>
            {errors.technicalSkills && (
              <p className="text-[11px] text-rose-500 mt-1">{errors.technicalSkills}</p>
            )}
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{isEditing ? 'Save Changes' : 'Add Student Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
