import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { Student } from '../types';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  student: Student | null;
  onClose: () => void;
  onConfirm: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  student,
  onClose,
  onConfirm
}) => {
  if (!isOpen || !student) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-xl border border-slate-200 overflow-hidden">
        <div className="p-6">
          <div className="flex items-center gap-3 text-rose-600 mb-4">
            <div className="p-2.5 bg-rose-50 rounded-xl">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Delete Student Record</h3>
              <p className="text-xs text-slate-500">Academic Database Operation</p>
            </div>
          </div>

          <p className="text-sm text-slate-600 mb-4">
            Are you sure you want to delete the placement record for{' '}
            <strong className="text-slate-900">{student.name}</strong> ({student.id})? This action will recalculate all live placement analytics and summary metrics.
          </p>

          <div className="p-3 bg-slate-50 rounded-lg text-xs text-slate-500 space-y-1 mb-5 border border-slate-200/60">
            <div><strong>Department:</strong> {student.department}</div>
            <div><strong>Placement Status:</strong> {student.placementStatus} {student.placementStatus === 'Placed' ? `(${student.companyName} · ${student.salaryPackage} LPA)` : ''}</div>
          </div>

          <div className="flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="px-4 py-2 text-sm font-semibold bg-rose-600 hover:bg-rose-700 text-white rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete Record</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
