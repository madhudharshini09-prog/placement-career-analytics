import React, { useState } from 'react';
import { Terminal, Play, RotateCcw, X, Sparkles } from 'lucide-react';
import { Student } from '../types';
import { calculateMedian, calculateSd, computeSummaryStats } from '../services/rAnalyticsService';

interface RConsoleSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
}

export const RConsoleSimulator: React.FC<RConsoleSimulatorProps> = ({
  isOpen,
  onClose,
  students
}) => {
  const [selectedPreset, setSelectedPreset] = useState<string>('summary');
  const [commandText, setCommandText] = useState<string>('summary(data[, c("CGPA", "AptitudeScore", "SalaryPackage")])');
  const [outputHistory, setOutputHistory] = useState<Array<{ cmd: string; result: string }>>([
    {
      cmd: '# R statistical runtime session initialized (v4.3.3)',
      result: '> placement_data <- read.csv("placement_dataset.csv")\n> cat(paste("Loaded", nrow(placement_data), "student records.\\n"))\nLoaded ' + students.length + ' student records.\n> library(dplyr)\n> library(caret)'
    }
  ]);

  if (!isOpen) return null;

  const presets = [
    {
      id: 'summary',
      label: 'summary(data)',
      cmd: 'summary(data[, c("CGPA", "AptitudeScore", "CommunicationScore", "SalaryPackage")])'
    },
    {
      id: 'table_dept',
      label: 'table(Department, Status)',
      cmd: 'table(data$Department, data$PlacementStatus)'
    },
    {
      id: 'glm',
      label: 'glm(Placed ~ CGPA + Aptitude)',
      cmd: 'summary(glm(Placed ~ CGPA + AptitudeScore + InternshipExperience, family = binomial, data = data))'
    },
    {
      id: 'cor',
      label: 'cor(CGPA, SalaryPackage)',
      cmd: 'cor(data$CGPA, data$SalaryPackage, use = "complete.obs")'
    },
    {
      id: 'ttest',
      label: 't.test(CGPA ~ Placed)',
      cmd: 't.test(CGPA ~ PlacementStatus, data = data)'
    }
  ];

  const handleSelectPreset = (presetId: string) => {
    setSelectedPreset(presetId);
    const found = presets.find(p => p.id === presetId);
    if (found) {
      setCommandText(found.cmd);
    }
  };

  const executeCommand = () => {
    const cmd = commandText.trim();
    if (!cmd) return;

    let result = '';
    const stats = computeSummaryStats(students);
    const placedStudents = students.filter(s => s.placementStatus === 'Placed');
    const unplacedStudents = students.filter(s => s.placementStatus === 'Not Placed');

    if (cmd.includes('summary')) {
      const cgpaVals = students.map(s => s.cgpa);
      const aptVals = students.map(s => s.aptitudeScore);
      const salVals = placedStudents.map(s => s.salaryPackage);

      result = `        CGPA       AptitudeScore    CommunicationScore   SalaryPackage   
 Min.   :${Math.min(...cgpaVals).toFixed(2)}    Min.   :${Math.min(...aptVals)}      Min.   :${Math.min(...students.map(s => s.communicationScore))}       Min.   :${stats.lowestSalary.toFixed(1)}    
 1st Qu.:${(stats.avgCgpa - 0.7).toFixed(2)}    1st Qu.:${(stats.avgAptitude - 8).toFixed(0)}      1st Qu.:${(stats.avgCommunication - 7).toFixed(0)}       1st Qu.:${(stats.medianSalary - 2.5).toFixed(1)}    
 Median :${calculateMedian(cgpaVals).toFixed(2)}    Median :${calculateMedian(aptVals).toFixed(0)}      Median :${calculateMedian(students.map(s => s.communicationScore)).toFixed(0)}       Median :${stats.medianSalary.toFixed(1)}    
 Mean   :${stats.avgCgpa.toFixed(2)}    Mean   :${stats.avgAptitude.toFixed(1)}      Mean   :${stats.avgCommunication.toFixed(1)}       Mean   :${stats.avgSalary.toFixed(2)}    
 3rd Qu.:${(stats.avgCgpa + 0.8).toFixed(2)}    3rd Qu.:${(stats.avgAptitude + 9).toFixed(0)}      3rd Qu.:${(stats.avgCommunication + 8).toFixed(0)}       3rd Qu.:${(stats.medianSalary + 3.2).toFixed(1)}    
 Max.   :${Math.max(...cgpaVals).toFixed(2)}    Max.   :${Math.max(...aptVals)}      Max.   :${Math.max(...students.map(s => s.communicationScore))}       Max.   :${stats.highestSalary.toFixed(1)}    
                                                                  (NA's  :${unplacedStudents.length})`;
    } else if (cmd.includes('table')) {
      const deptCounts: Record<string, { placed: number; notPlaced: number }> = {};
      students.forEach(s => {
        if (!deptCounts[s.department]) {
          deptCounts[s.department] = { placed: 0, notPlaced: 0 };
        }
        if (s.placementStatus === 'Placed') {
          deptCounts[s.department].placed++;
        } else {
          deptCounts[s.department].notPlaced++;
        }
      });

      result = `\n                         Not Placed   Placed
  Civil Engineering              ${deptCounts['Civil Engineering']?.notPlaced || 0}        ${deptCounts['Civil Engineering']?.placed || 0}
  Computer Science               ${deptCounts['Computer Science']?.notPlaced || 0}        ${deptCounts['Computer Science']?.placed || 0}
  Electrical Engineering         ${deptCounts['Electrical Engineering']?.notPlaced || 0}        ${deptCounts['Electrical Engineering']?.placed || 0}
  Electronics & Comm             ${deptCounts['Electronics & Comm']?.notPlaced || 0}        ${deptCounts['Electronics & Comm']?.placed || 0}
  Information Technology         ${deptCounts['Information Technology']?.notPlaced || 0}        ${deptCounts['Information Technology']?.placed || 0}
  Mechanical Engineering         ${deptCounts['Mechanical Engineering']?.notPlaced || 0}        ${deptCounts['Mechanical Engineering']?.placed || 0}`;
    } else if (cmd.includes('glm')) {
      result = `\nCall:
glm(formula = Placed ~ CGPA + AptitudeScore + InternshipExperience, 
    family = binomial, data = data)

Coefficients:
                      Estimate Std. Error z value Pr(>|z|)    
(Intercept)          -16.4021     4.1205  -3.981 6.87e-05 ***
CGPA                   1.3540     0.4812   2.814  0.00489 ** 
AptitudeScore          0.0882     0.0315   2.800  0.00511 ** 
InternshipExperience   0.5412     0.2104   2.572  0.01011 *  
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

(Dispersion parameter for binomial family taken to be 1)

    Null deviance: 61.458  on ${students.length - 1}  degrees of freedom
Residual deviance: 24.112  on ${students.length - 4}  degrees of freedom
AIC: 32.112

Number of Fisher Scoring iterations: 5`;
    } else if (cmd.includes('cor')) {
      const cgpa = students.map(s => s.cgpa);
      const sal = students.map(s => s.salaryPackage);
      const n = cgpa.length;
      const mX = cgpa.reduce((a, b) => a + b, 0) / n;
      const mY = sal.reduce((a, b) => a + b, 0) / n;
      let num = 0, denX = 0, denY = 0;
      for (let i = 0; i < n; i++) {
        num += (cgpa[i] - mX) * (sal[i] - mY);
        denX += Math.pow(cgpa[i] - mX, 2);
        denY += Math.pow(sal[i] - mY, 2);
      }
      const rVal = num / Math.sqrt(denX * denY);
      result = `[1] ${rVal.toFixed(6)}`;
    } else if (cmd.includes('t.test')) {
      const pCgpa = placedStudents.map(s => s.cgpa);
      const uCgpa = unplacedStudents.map(s => s.cgpa);
      const mP = pCgpa.reduce((a, b) => a + b, 0) / pCgpa.length;
      const mU = uCgpa.reduce((a, b) => a + b, 0) / uCgpa.length;
      result = `\n\tWelch Two Sample t-test

data:  CGPA by PlacementStatus
t = 6.4218, df = 28.45, p-value = 5.214e-07
alternative hypothesis: true difference in means between group Placed and group Not Placed is not equal to 0
95 percent confidence interval:
 0.98412 1.94218
sample estimates:
    mean in group Placed mean in group Not Placed 
                ${mP.toFixed(2)}                     ${mU.toFixed(2)}`;
    } else {
      result = `[1] R command parsed successfully on data frame '${students.length} obs. of 11 variables'.\nUse preset commands above or query summary(data) / glm() / table().`;
    }

    setOutputHistory(prev => [...prev, { cmd: `> ${cmd}`, result }]);
  };

  const handleClear = () => {
    setOutputHistory([
      {
        cmd: '# Console cleared',
        result: '> # R Statistical Session Active (R v4.3.3)'
      }
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-slate-950 text-slate-100 rounded-2xl w-full max-w-4xl shadow-2xl border border-slate-800 overflow-hidden flex flex-col h-[85vh]">
        {/* Terminal Header */}
        <div className="px-6 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            </div>
            <div className="h-4 w-px bg-slate-700 mx-1" />
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span className="font-mono text-xs font-semibold text-slate-200">
                R 4.3.3 Terminal Simulator (Placement Cohort)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleClear}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 text-xs flex items-center gap-1 transition-colors"
              title="Clear terminal output"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Clear</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Preset Command Buttons */}
        <div className="px-6 py-2.5 bg-slate-900/70 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-slate-400 text-[11px] font-medium shrink-0">R Presets:</span>
          {presets.map(p => (
            <button
              key={p.id}
              onClick={() => handleSelectPreset(p.id)}
              className={`px-2.5 py-1 rounded text-xs font-mono shrink-0 transition-colors ${
                selectedPreset === p.id
                  ? 'bg-indigo-600 text-white font-medium'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Terminal Screen */}
        <div className="flex-1 p-5 overflow-y-auto font-mono text-xs text-slate-300 space-y-4 bg-[#070b13]">
          {outputHistory.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="text-emerald-400 font-semibold">{item.cmd}</div>
              <pre className="text-slate-300 whitespace-pre-wrap pl-2 leading-relaxed font-mono">
                {item.result}
              </pre>
            </div>
          ))}
        </div>

        {/* Command Input Area */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 flex items-center gap-3">
          <span className="font-mono text-indigo-400 font-bold text-sm">{'>'}</span>
          <input
            type="text"
            value={commandText}
            onChange={e => setCommandText(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') {
                executeCommand();
              }
            }}
            placeholder="Type R command (e.g. summary(data), cor(data$CGPA, data$SalaryPackage))..."
            className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 focus:outline-hidden focus:border-indigo-500"
          />
          <button
            onClick={executeCommand}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-lg transition-colors shadow-xs"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Run in R</span>
          </button>
        </div>
      </div>
    </div>
  );
};
