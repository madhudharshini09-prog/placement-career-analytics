import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  iconBgColor?: string;
  iconTextColor?: string;
  trend?: string;
  trendPositive?: boolean;
  rFormula?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  iconBgColor = 'bg-blue-50',
  iconTextColor = 'text-blue-600',
  trend,
  trendPositive = true,
  rFormula,
}) => {
  return (
    <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-2xs transition-all hover:shadow-xs">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">
            {title}
          </p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-2xl font-bold text-slate-900 tracking-tight font-sans">
              {value}
            </h3>
            {trend && (
              <span className={`text-xs font-semibold ${trendPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
                {trend}
              </span>
            )}
          </div>
        </div>

        <div className={`p-2.5 rounded-lg ${iconBgColor} ${iconTextColor}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
        <span className="truncate">{subtitle || 'Academic Batch 2024-25'}</span>
        {rFormula && (
          <code className="text-[11px] font-mono text-indigo-600 font-medium bg-slate-50 px-1.5 py-0.5 rounded border border-slate-200/60">
            {rFormula}
          </code>
        )}
      </div>
    </div>
  );
};
