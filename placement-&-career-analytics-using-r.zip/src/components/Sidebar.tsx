import React from 'react';
import { 
  Home, 
  LayoutDashboard, 
  Users, 
  BarChart3, 
  Compass, 
  BrainCircuit, 
  FileText, 
  Info, 
  X,
  Binary
} from 'lucide-react';

export type ActiveTab = 
  | 'home' 
  | 'dashboard' 
  | 'students' 
  | 'analytics' 
  | 'career' 
  | 'prediction' 
  | 'reports' 
  | 'about';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isOpen,
  onClose
}) => {
  const menuItems = [
    { id: 'home' as ActiveTab, label: 'Home Overview', icon: Home },
    { id: 'dashboard' as ActiveTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'students' as ActiveTab, label: 'Student Records', icon: Users },
    { id: 'analytics' as ActiveTab, label: 'Placement Analytics', icon: BarChart3 },
    { id: 'career' as ActiveTab, label: 'Career Analytics', icon: Compass },
    { id: 'prediction' as ActiveTab, label: 'Placement Predictor', icon: BrainCircuit },
    { id: 'reports' as ActiveTab, label: 'Academic Reports', icon: FileText },
    { id: 'about' as ActiveTab, label: 'About & R Methodology', icon: Info },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-xs transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-700 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <span className="font-mono font-bold text-lg tracking-tighter">R</span>
            </div>
            <div>
              <h1 className="font-bold text-slate-900 text-sm tracking-tight leading-tight">
                Placement & Career Analytics
              </h1>
              <p className="text-xs text-indigo-600 font-medium">Powered by R Programming</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg lg:hidden"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Academic Project Badge */}
        <div className="px-5 py-3 bg-slate-50/80 border-b border-slate-100 text-xs text-slate-600 flex items-center justify-between">
          <span className="font-medium text-slate-700">Academic Project</span>
          <span className="font-mono text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded text-[11px] font-semibold">
            R v4.3.3
          </span>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs border-l-4 border-blue-600 pl-2.5'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* R Computational Engine Status Card */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/60">
          <div className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                <Binary className="w-3.5 h-3.5 text-indigo-600" />
                R Statistical Kernel
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Logistic Regression (GLM) & Decision Tree calibrated on empirical placement cohort.
            </p>
            <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>dplyr · ggplot2</span>
              <span>caret · plumber</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
