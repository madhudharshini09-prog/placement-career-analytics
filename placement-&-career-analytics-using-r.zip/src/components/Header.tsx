import React from 'react';
import { Menu, Download, Printer, Terminal, Sparkles } from 'lucide-react';
import { ActiveTab } from './Sidebar';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenSidebar: () => void;
  totalStudents: number;
  placementRate: number;
  onExportCsv: () => void;
  onPrint: () => void;
  onOpenRConsole: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenSidebar,
  totalStudents,
  placementRate,
  onExportCsv,
  onPrint,
  onOpenRConsole
}) => {
  const getTabTitle = (tab: ActiveTab) => {
    switch (tab) {
      case 'home':
        return { title: 'Placement & Career Analytics', subtitle: 'Student Placement Insights Powered by R Programming' };
      case 'dashboard':
        return { title: 'Executive Placement Dashboard', subtitle: 'Real-time cohort metrics, conversion rates, and salary distributions' };
      case 'students':
        return { title: 'Student Data Management', subtitle: 'Search, filter, manage, and audit student placement credentials' };
      case 'analytics':
        return { title: 'Placement Analytics & Modeling', subtitle: 'Statistical distributions, CGPA regressions, and cross-tabulations' };
      case 'career':
        return { title: 'Career Analytics & Skill Gaps', subtitle: 'Targeted employability roadmaps and industry demand benchmarks' };
      case 'prediction':
        return { title: 'Placement Likelihood Predictor', subtitle: 'Calibrated Binomial Logistic Regression & Decision Tree estimation' };
      case 'reports':
        return { title: 'Academic Placement Reports', subtitle: 'Comprehensive institutional summary tables ready for presentation & export' };
      case 'about':
        return { title: 'Project Overview & R Architecture', subtitle: 'Technical documentation, methodology, packages, and reproducible scripts' };
    }
  };

  const { title, subtitle } = getTabTitle(activeTab);

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3.5 transition-all">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile Toggle + Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenSidebar}
            className="p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg lg:hidden hover:bg-slate-100 transition-colors"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                {title}
              </h2>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              {subtitle}
            </p>
          </div>
        </div>

        {/* Right: Quick Stats & Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3 action-buttons">
          {/* Live Cohort Chip */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
            <span className="text-slate-500 font-medium">{totalStudents} Candidates</span>
            <span className="text-slate-300">|</span>
            <span className="font-semibold text-emerald-600">{placementRate}% Placed</span>
          </div>

          {/* R Interactive Console Button */}
          <button
            onClick={onOpenRConsole}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200/80 transition-colors"
            title="Open Interactive R Terminal Simulator"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">R Console</span>
          </button>

          {/* CSV Export Button */}
          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white text-slate-700 hover:bg-slate-50 border border-slate-200 shadow-2xs transition-colors"
            title="Export Records to CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {/* Print / Save PDF Button */}
          <button
            onClick={onPrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 shadow-xs transition-colors"
            title="Print or Save Report as PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print Report</span>
          </button>
        </div>
      </div>
    </header>
  );
};
