import React, { useState } from 'react';
import { 
  FileCode2, 
  Terminal, 
  CheckCircle2, 
  BookOpen, 
  Layers, 
  Cpu, 
  ExternalLink, 
  Copy, 
  Check, 
  Download,
  Info
} from 'lucide-react';
import { R_SCRIPTS, RScriptItem } from '../data/rScriptsData';

interface AboutProjectPageProps {
  onOpenRModalWithCode: (code: string, title: string, filename?: string) => void;
}

export const AboutProjectPage: React.FC<AboutProjectPageProps> = ({
  onOpenRModalWithCode
}) => {
  const [activeScriptId, setActiveScriptId] = useState<string>(R_SCRIPTS[0].id);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activeScript = R_SCRIPTS.find(s => s.id === activeScriptId) || R_SCRIPTS[0];

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (script: RScriptItem) => {
    const blob = new Blob([script.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = script.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Project Overview Card */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Final Year Academic Engineering Project</span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Placement and Career Analytics using R Programming
        </h2>

        <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-4xl">
          This academic project addresses the growing demand for data-driven student placement decision-making in technical higher education institutions. By leveraging <strong>R programming</strong>, statistical computing principles, and machine learning models, the system aggregates multi-dimensional student performance indicators (CGPA, standardized aptitude scores, verbal communication assessments, internships, and technical skill portfolios) to deliver institutional intelligence and personalized career roadmap recommendations.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-100">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-1">Project Scope</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Encompasses multi-department student performance audits, salary variance analysis, skills gap detection, and real-time placement probability estimation.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-1">Target Beneficiaries</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Training & Placement Officers (TPOs), Department Heads, Academic Evaluators, and Engineering Undergraduates preparing for campus hiring.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-1">Key Outcomes</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Increases institutional placement conversion rates, highlights high-demand curriculum gaps, and guides student preparation using empirical data.
            </p>
          </div>
        </div>
      </div>

      {/* R Programming Role in the Project */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/90 shadow-2xs space-y-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900">
            How R Programming is Utilized Across the Analytics Lifecycle
          </h3>
          <p className="text-xs sm:text-sm text-slate-500">
            R was selected for its robust statistical foundational packages, unmatched data wrangling capabilities, and reproducible reporting.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Package 1: dplyr & tidyr */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
            <span className="font-mono text-xs font-bold text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded">
              dplyr & tidyr
            </span>
            <h4 className="font-bold text-slate-900 text-sm">Data Wrangling & Cleaning</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Executes pipeline transformations (<code className="font-mono text-slate-700">{'%>%'}</code>), filtering anomalies, handling missing scores, and computing department aggregations via <code className="font-mono text-slate-700">group_by()</code> and <code className="font-mono text-slate-700">summarise()</code>.
            </p>
          </div>

          {/* Package 2: ggplot2 */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
            <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-100/70 px-2 py-0.5 rounded">
              ggplot2 & scales
            </span>
            <h4 className="font-bold text-slate-900 text-sm">Statistical Data Visualization</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Constructs publication-grade grammar-of-graphics plots: salary distributions, department conversion rates, box plots, and correlation heatmaps.
            </p>
          </div>

          {/* Package 3: caret & stats */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
            <span className="font-mono text-xs font-bold text-purple-700 bg-purple-100/70 px-2 py-0.5 rounded">
              caret & glm
            </span>
            <h4 className="font-bold text-slate-900 text-sm">Machine Learning Modeling</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Fits Binomial Logistic Regression models using <code className="font-mono text-slate-700">glm()</code> to estimate placement odds ratios, compute 95% confidence intervals, and extract feature coefficients.
            </p>
          </div>

          {/* Package 4: plumber */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
            <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
              plumber & jsonlite
            </span>
            <h4 className="font-bold text-slate-900 text-sm">REST API Integration</h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Converts trained R machine learning models into microservice endpoints (<code className="font-mono text-slate-700">/predict</code>) consumed seamlessly by the frontend dashboard.
            </p>
          </div>
        </div>
      </div>

      {/* R Scripts Showcase & Download Center */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-indigo-400" />
              <h3 className="text-lg font-bold text-white">
                R Programming Source Scripts & Reproducible Code
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Complete, fully-documented R scripts ready for evaluation in RStudio or command line
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopy(activeScript.code, activeScript.id)}
              className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copiedId === activeScript.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copiedId === activeScript.id ? 'Copied' : 'Copy Active Script'}</span>
            </button>

            <button
              onClick={() => handleDownload(activeScript)}
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download {activeScript.filename}</span>
            </button>
          </div>
        </div>

        {/* Script Selection Tabs */}
        <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
          {R_SCRIPTS.map(script => (
            <button
              key={script.id}
              onClick={() => setActiveScriptId(script.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                activeScriptId === script.id
                  ? 'bg-indigo-600 text-white shadow-xs font-semibold'
                  : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              {script.name}
            </button>
          ))}
        </div>

        {/* Script Details Card */}
        <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
            <span className="text-indigo-400 font-mono font-semibold">{activeScript.filename}</span>
            <div className="flex items-center gap-2 text-slate-400 text-[11px]">
              <span>Required packages:</span>
              <div className="flex gap-1">
                {activeScript.packages.map(p => (
                  <span key={p} className="bg-slate-800 px-1.5 py-0.5 rounded text-slate-300 font-mono">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-300">{activeScript.description}</p>
        </div>

        {/* Code Preview Box */}
        <div className="p-5 rounded-xl bg-[#090d16] border border-slate-800 max-h-96 overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed">
          <pre className="whitespace-pre-wrap">{activeScript.code}</pre>
        </div>
      </div>

      {/* Local Execution & Deployment Guide */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/90 shadow-2xs space-y-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900">
            Step-by-Step Instructions for Local Execution
          </h3>
          <p className="text-xs sm:text-sm text-slate-500">
            How to run this project on an academic evaluation machine with R and RStudio
          </p>
        </div>

        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
              Step 1: Install R and RStudio Desktop
            </h4>
            <p className="text-xs text-slate-600">
              Download and install R (v4.2.0 or newer) from{' '}
              <a href="https://cran.r-project.org" target="_blank" rel="noreferrer" className="text-blue-600 underline">
                cran.r-project.org
              </a>{' '}
              and RStudio Desktop from Posit.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
              Step 2: Install Required R Packages
            </h4>
            <p className="text-xs text-slate-600">
              Run this single command in the RStudio console to automatically install all dependencies:
            </p>
            <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-xs rounded-lg overflow-x-auto">
              install.packages(c("tidyverse", "caret", "rpart", "rpart.plot", "pROC", "corrplot", "plumber", "jsonlite", "psych"))
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
              Step 3: Run the Plumber REST API Server (Optional Backend)
            </h4>
            <p className="text-xs text-slate-600">
              To host the live R prediction microservice locally on port 8000:
            </p>
            <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-xs rounded-lg overflow-x-auto">
              plumber::pr("04_plumber_api.R") %&gt;% plumber::pr_run(port = 8000)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
