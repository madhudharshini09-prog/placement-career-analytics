import React, { useMemo } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Building2, 
  GraduationCap, 
  Award, 
  CheckCircle2, 
  BarChart, 
  Calendar,
  FileSpreadsheet
} from 'lucide-react';
import { 
  computeCompanyStats, 
  computeDepartmentStats, 
  computeSummaryStats 
} from '../services/rAnalyticsService';
import { getInDemandSkillsAnalysis } from '../services/careerRecommendationService';
import { Student } from '../types';

interface ReportsPageProps {
  students: Student[];
  onExportCsv: () => void;
  onPrint: () => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({
  students,
  onExportCsv,
  onPrint
}) => {
  const stats = useMemo(() => computeSummaryStats(students), [students]);
  const deptStats = useMemo(() => computeDepartmentStats(students), [students]);
  const companyStats = useMemo(() => computeCompanyStats(students), [students]);
  const skillAnalysis = useMemo(() => getInDemandSkillsAnalysis(students), [students]);

  const reportDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Top Controls (Hidden during print) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 no-print">
        <div>
          <h3 className="font-bold text-slate-900 text-base">Academic Placement & Career Report</h3>
          <p className="text-xs text-slate-500">
            Formal institutional placement documentation generated for academic accreditation and review
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onExportCsv}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Download CSV Data</span>
          </button>

          <button
            onClick={onPrint}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save as PDF</span>
          </button>
        </div>
      </div>

      {/* Official Report Document Container */}
      <div className="bg-white p-8 sm:p-12 rounded-2xl border border-slate-200 shadow-sm space-y-8 print:p-0 print:border-none print:shadow-none card-print">
        {/* Document Header */}
        <div className="border-b-2 border-slate-900 pb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[11px] font-bold tracking-widest text-indigo-700 uppercase">
              College of Engineering & Technology
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Annual Placement & Career Analytics Report
            </h1>
            <p className="text-xs text-slate-500">
              Computational Statistics & Empirical Predictions Powered by R Programming
            </p>
          </div>

          <div className="text-left sm:text-right space-y-0.5 text-xs text-slate-600 font-mono">
            <div><strong>Report Ref:</strong> PLAC-R-2025-01</div>
            <div><strong>Batch:</strong> 2024-2025 Academic Year</div>
            <div><strong>Generated:</strong> {reportDate}</div>
            <div><strong>Engine:</strong> R v4.3.3 (dplyr / caret)</div>
          </div>
        </div>

        {/* 1. Executive Summary Table */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
              1. Institutional Cohort Key Metrics
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="text-xs text-slate-500">Total Enrolled</div>
              <div className="text-xl font-bold text-slate-900 font-mono">{stats.totalStudents} Candidates</div>
            </div>
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl">
              <div className="text-xs text-emerald-700 font-medium">Offers Confirmed</div>
              <div className="text-xl font-bold text-emerald-800 font-mono">{stats.placedStudents} Placed</div>
            </div>
            <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl">
              <div className="text-xs text-indigo-700 font-medium">Placement Rate</div>
              <div className="text-xl font-bold text-indigo-800 font-mono">{stats.placementRate}%</div>
            </div>
            <div className="p-3 bg-purple-50/70 border border-purple-200 rounded-xl">
              <div className="text-xs text-purple-700 font-medium">Average Package</div>
              <div className="text-xl font-bold text-purple-800 font-mono">₹{stats.avgSalary} LPA</div>
            </div>
          </div>
        </div>

        {/* 2. Department-Wise Placement Performance */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
              2. Department-Wise Placement Performance Breakdown
            </h3>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left text-slate-700">
              <thead className="bg-slate-100/80 font-bold uppercase text-[11px] text-slate-800 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Department</th>
                  <th className="py-2.5 px-3 text-center">Enrolled</th>
                  <th className="py-2.5 px-3 text-center">Placed</th>
                  <th className="py-2.5 px-3 text-center">Unplaced</th>
                  <th className="py-2.5 px-3 text-center">Placement Rate</th>
                  <th className="py-2.5 px-3 text-center">Avg CGPA</th>
                  <th className="py-2.5 px-3 text-right">Avg Package</th>
                  <th className="py-2.5 px-3 text-right">Highest Package</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {deptStats.map(dept => (
                  <tr key={dept.department} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">{dept.department}</td>
                    <td className="py-2.5 px-3 text-center">{dept.total}</td>
                    <td className="py-2.5 px-3 text-center text-emerald-700 font-bold">{dept.placed}</td>
                    <td className="py-2.5 px-3 text-center text-slate-500">{dept.unplaced}</td>
                    <td className="py-2.5 px-3 text-center font-bold text-blue-700">{dept.placementRate}%</td>
                    <td className="py-2.5 px-3 text-center">{dept.avgCgpa}</td>
                    <td className="py-2.5 px-3 text-right font-bold">₹{dept.avgPackage} LPA</td>
                    <td className="py-2.5 px-3 text-right text-indigo-700 font-bold">₹{dept.highestPackage} LPA</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 3. Salary Statistical Metrics */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <BarChart className="w-4 h-4 text-purple-600" />
            <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
              3. Salary Distribution Statistical Measures (R stats::summary)
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center">
              <span className="text-[11px] text-slate-500 block">Mean Package</span>
              <strong className="text-base text-slate-900 font-mono">₹{stats.avgSalary} LPA</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center">
              <span className="text-[11px] text-slate-500 block">Median Package</span>
              <strong className="text-base text-slate-900 font-mono">₹{stats.medianSalary} LPA</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center">
              <span className="text-[11px] text-slate-500 block">Standard Dev (sd)</span>
              <strong className="text-base text-slate-900 font-mono">₹{stats.salaryStdDev}</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center">
              <span className="text-[11px] text-slate-500 block">Highest Package</span>
              <strong className="text-base text-slate-900 font-mono text-emerald-700">₹{stats.highestSalary} LPA</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center">
              <span className="text-[11px] text-slate-500 block">Lowest Package</span>
              <strong className="text-base text-slate-900 font-mono">₹{stats.lowestSalary} LPA</strong>
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center">
              <span className="text-[11px] text-slate-500 block">Average CGPA</span>
              <strong className="text-base text-slate-900 font-mono">{stats.avgCgpa} / 10</strong>
            </div>
          </div>
        </div>

        {/* 4. Company Recruitment Statistics */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
              4. Company-Wise Recruitment & Tier Classification
            </h3>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left text-slate-700">
              <thead className="bg-slate-100/80 font-bold uppercase text-[11px] text-slate-800 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Recruiting Organization</th>
                  <th className="py-2.5 px-3">Industry Tier</th>
                  <th className="py-2.5 px-3 text-center">Total Hires</th>
                  <th className="py-2.5 px-3 text-right">Average Package</th>
                  <th className="py-2.5 px-3 text-right">Highest Offer</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {companyStats.map(c => (
                  <tr key={c.company} className="hover:bg-slate-50/70">
                    <td className="py-2 px-3 font-sans font-semibold text-slate-900">{c.company}</td>
                    <td className="py-2 px-3 font-sans text-slate-600">{c.tier}</td>
                    <td className="py-2 px-3 text-center font-bold text-slate-800">{c.count}</td>
                    <td className="py-2 px-3 text-right font-bold text-slate-900">₹{c.avgPackage} LPA</td>
                    <td className="py-2 px-3 text-right text-indigo-700 font-bold">₹{c.highestPackage} LPA</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 5. Institutional Sign-Off Block for Academic Evaluation */}
        <div className="pt-8 border-t border-slate-200 grid grid-cols-3 gap-6 text-xs text-slate-600">
          <div className="space-y-8">
            <div className="border-b border-slate-400 pb-1 font-mono text-[11px]">Prepared By:</div>
            <div>
              <div className="font-bold text-slate-900">Academic Project Team</div>
              <div className="text-[11px] text-slate-500">Dept. of Computer Science & Eng.</div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="border-b border-slate-400 pb-1 font-mono text-[11px]">Verified By:</div>
            <div>
              <div className="font-bold text-slate-900">Head of Training & Placement (TPO)</div>
              <div className="text-[11px] text-slate-500">Corporate Relations Cell</div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="border-b border-slate-400 pb-1 font-mono text-[11px]">Approved By:</div>
            <div>
              <div className="font-bold text-slate-900">Project Guide & Dean Academics</div>
              <div className="text-[11px] text-slate-500">College Academic Council</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
