import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Edit2, 
  Trash2, 
  RotateCcw, 
  Download, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  Building,
  GraduationCap
} from 'lucide-react';
import { DEPARTMENTS } from '../data/studentsData';
import { Department, PlacementStatus, Student } from '../types';

interface StudentDataPageProps {
  students: Student[];
  onAddStudent: () => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (student: Student) => void;
  onResetData: () => void;
  onExportCsv: () => void;
}

type SortField = 'name' | 'id' | 'department' | 'cgpa' | 'aptitudeScore' | 'communicationScore' | 'salaryPackage' | 'placementStatus';

export const StudentDataPage: React.FC<StudentDataPageProps> = ({
  students,
  onAddStudent,
  onEditStudent,
  onDeleteStudent,
  onResetData,
  onExportCsv
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [minCgpa, setMinCgpa] = useState<number>(0);
  const [sortField, setSortField] = useState<SortField>('cgpa');
  const [sortAsc, setSortAsc] = useState<boolean>(false); // default desc for CGPA
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 12;

  // Filtering logic
  const filteredStudents = useMemo(() => {
    return students.filter(student => {
      // Search matches name, id, company, or skills
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        student.name.toLowerCase().includes(q) ||
        student.id.toLowerCase().includes(q) ||
        student.companyName.toLowerCase().includes(q) ||
        student.technicalSkills.some(skill => skill.toLowerCase().includes(q));

      // Department filter
      const matchesDept = selectedDept === 'All' || student.department === selectedDept;

      // Status filter
      const matchesStatus = selectedStatus === 'All' || student.placementStatus === selectedStatus;

      // Min CGPA filter
      const matchesCgpa = student.cgpa >= minCgpa;

      return matchesSearch && matchesDept && matchesStatus && matchesCgpa;
    });
  }, [students, searchQuery, selectedDept, selectedStatus, minCgpa]);

  // Sorting logic
  const sortedStudents = useMemo(() => {
    return [...filteredStudents].sort((a, b) => {
      let comparison = 0;
      if (sortField === 'cgpa' || sortField === 'aptitudeScore' || sortField === 'communicationScore' || sortField === 'salaryPackage') {
        comparison = a[sortField] - b[sortField];
      } else {
        comparison = String(a[sortField]).localeCompare(String(b[sortField]));
      }
      return sortAsc ? comparison : -comparison;
    });
  }, [filteredStudents, sortField, sortAsc]);

  // Pagination
  const totalPages = Math.ceil(sortedStudents.length / pageSize) || 1;
  const paginatedStudents = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedStudents.slice(start, start + pageSize);
  }, [sortedStudents, currentPage]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false); // default descending
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />;
    }
    return sortAsc 
      ? <ArrowUp className="w-3.5 h-3.5 text-blue-600" /> 
      : <ArrowDown className="w-3.5 h-3.5 text-blue-600" />;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Action & Control Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Student Placement Registry</h3>
            <p className="text-xs text-slate-500">
              Showing {filteredStudents.length} of {students.length} candidates across academic batches
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onResetData}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Reset records to default sample dataset"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Default Data</span>
            </button>

            <button
              onClick={onExportCsv}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
              title="Export filtered records to CSV"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={onAddStudent}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Student Record</span>
            </button>
          </div>
        </div>

        {/* Search & Filter Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
          {/* Search box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by student, ID, company, skill..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={selectedDept}
              onChange={e => {
                setSelectedDept(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="All">All Departments</option>
              {DEPARTMENTS.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          {/* Placement Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={e => {
                setSelectedStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="All">All Placement Statuses</option>
              <option value="Placed">Placed Candidates Only</option>
              <option value="Not Placed">Not Placed Only</option>
            </select>
          </div>

          {/* Min CGPA Filter */}
          <div className="flex items-center gap-2 px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg">
            <span className="text-[11px] font-semibold text-slate-500 whitespace-nowrap">
              Min CGPA: {minCgpa > 0 ? minCgpa : 'Any'}
            </span>
            <input
              type="range"
              min="0"
              max="9"
              step="0.5"
              value={minCgpa}
              onChange={e => {
                setMinCgpa(parseFloat(e.target.value));
                setCurrentPage(1);
              }}
              className="w-full accent-blue-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
            />
          </div>
        </div>
      </div>

      {/* Main Student Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors"
                  onClick={() => handleSort('id')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Student ID</span>
                    {getSortIcon('id')}
                  </div>
                </th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors"
                  onClick={() => handleSort('name')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Name</span>
                    {getSortIcon('name')}
                  </div>
                </th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors"
                  onClick={() => handleSort('department')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Department</span>
                    {getSortIcon('department')}
                  </div>
                </th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors text-right"
                  onClick={() => handleSort('cgpa')}
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>CGPA</span>
                    {getSortIcon('cgpa')}
                  </div>
                </th>
                <th className="py-3 px-4">Technical Skills</th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors text-center"
                  onClick={() => handleSort('aptitudeScore')}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>Apt.</span>
                    {getSortIcon('aptitudeScore')}
                  </div>
                </th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors text-center"
                  onClick={() => handleSort('communicationScore')}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>Comm.</span>
                    {getSortIcon('communicationScore')}
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Intern</th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors text-center"
                  onClick={() => handleSort('placementStatus')}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>Status</span>
                    {getSortIcon('placementStatus')}
                  </div>
                </th>
                <th className="py-3 px-4">Company</th>
                <th 
                  className="py-3 px-4 cursor-pointer hover:bg-slate-100/80 transition-colors text-right"
                  onClick={() => handleSort('salaryPackage')}
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Package</span>
                    {getSortIcon('salaryPackage')}
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedStudents.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-12 text-center text-slate-400">
                    No student records matching current search or filters.
                  </td>
                </tr>
              ) : (
                paginatedStudents.map(student => {
                  const isPlaced = student.placementStatus === 'Placed';
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* ID */}
                      <td className="py-3 px-4 font-mono font-medium text-slate-900 text-[11px]">
                        {student.id}
                      </td>

                      {/* Name */}
                      <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap">
                        {student.name}
                      </td>

                      {/* Department */}
                      <td className="py-3 px-4 whitespace-nowrap text-slate-600">
                        {student.department}
                      </td>

                      {/* CGPA */}
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {student.cgpa.toFixed(2)}
                      </td>

                      {/* Technical Skills */}
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {student.technicalSkills.slice(0, 3).map(skill => (
                            <span 
                              key={skill}
                              className="px-1.5 py-0.5 text-[10px] font-medium bg-slate-100 text-slate-700 rounded"
                            >
                              {skill}
                            </span>
                          ))}
                          {student.technicalSkills.length > 3 && (
                            <span className="text-[10px] text-slate-400 font-medium">
                              +{student.technicalSkills.length - 3}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Aptitude */}
                      <td className="py-3 px-4 text-center font-mono text-slate-700">
                        {student.aptitudeScore}
                      </td>

                      {/* Communication */}
                      <td className="py-3 px-4 text-center font-mono text-slate-700">
                        {student.communicationScore}
                      </td>

                      {/* Internships */}
                      <td className="py-3 px-4 text-center font-mono text-slate-600">
                        {student.internshipExperience > 0 ? `${student.internshipExperience}m` : '0'}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold ${
                          isPlaced
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600 border border-slate-200'
                        }`}>
                          {student.placementStatus}
                        </span>
                      </td>

                      {/* Company */}
                      <td className="py-3 px-4 font-medium text-slate-900 whitespace-nowrap">
                        {isPlaced ? student.companyName : '-'}
                      </td>

                      {/* Salary */}
                      <td className="py-3 px-4 text-right font-mono font-bold whitespace-nowrap text-slate-900">
                        {isPlaced ? `₹${student.salaryPackage} LPA` : '-'}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => onEditStudent(student)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 rounded-md hover:bg-blue-50 transition-colors"
                            title="Edit Student Record"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteStudent(student)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md hover:bg-rose-50 transition-colors"
                            title="Delete Student Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer with Pagination */}
        <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>
            Showing <strong className="text-slate-700">{paginatedStudents.length}</strong> of{' '}
            <strong className="text-slate-700">{filteredStudents.length}</strong> filtered candidates
          </div>

          <div className="flex items-center gap-1.5">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              className="px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 font-medium cursor-pointer"
            >
              Previous
            </button>
            <span className="px-2 font-mono text-[11px]">
              Page {currentPage} of {totalPages}
            </span>
            <button
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              className="px-2.5 py-1 border border-slate-200 rounded bg-white text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 font-medium cursor-pointer"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
