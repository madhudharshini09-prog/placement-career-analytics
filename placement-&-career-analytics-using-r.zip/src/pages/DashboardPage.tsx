import React, { useMemo } from 'react';
import { 
  Users, 
  CheckCircle2, 
  XCircle, 
  TrendingUp, 
  Award, 
  DollarSign, 
  Building2, 
  BarChart as BarIcon,
  Sparkles
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
  Filler
} from 'chart.js';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import { StatCard } from '../components/StatCard';
import { 
  computeCompanyStats, 
  computeDepartmentStats, 
  computeSalaryDistribution, 
  computeSummaryStats 
} from '../services/rAnalyticsService';
import { Student } from '../types';

// Register ChartJS plugins
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
  Filler
);

interface DashboardPageProps {
  students: Student[];
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ students }) => {
  const stats = useMemo(() => computeSummaryStats(students), [students]);
  const deptStats = useMemo(() => computeDepartmentStats(students), [students]);
  const companyStats = useMemo(() => computeCompanyStats(students), [students]);
  const salaryDist = useMemo(() => computeSalaryDistribution(students), [students]);

  // 1. Department Placement Rate Chart Data (Bar)
  const deptChartData = {
    labels: deptStats.map(d => d.department.replace('Engineering', 'Eng.')),
    datasets: [
      {
        label: 'Placement Rate (%)',
        data: deptStats.map(d => d.placementRate),
        backgroundColor: 'rgba(59, 130, 246, 0.85)',
        hoverBackgroundColor: 'rgba(37, 99, 235, 1)',
        borderRadius: 8,
      },
      {
        label: 'Average CGPA (x10)',
        data: deptStats.map(d => d.avgCgpa * 10),
        backgroundColor: 'rgba(168, 85, 247, 0.4)',
        hoverBackgroundColor: 'rgba(168, 85, 247, 0.7)',
        borderRadius: 8,
      }
    ]
  };

  // 2. Placed vs Unplaced Doughnut Chart
  const statusDoughnutData = {
    labels: ['Placed Students', 'Not Placed / Seeking'],
    datasets: [
      {
        data: [stats.placedStudents, stats.unplacedStudents],
        backgroundColor: ['#2563eb', '#cbd5e1'],
        hoverBackgroundColor: ['#1d4ed8', '#94a3b8'],
        borderWidth: 0,
      }
    ]
  };

  // 3. Salary Bracket Distribution (Bar Chart)
  const salaryChartData = {
    labels: salaryDist.map(s => s.label),
    datasets: [
      {
        label: 'Number of Placed Students',
        data: salaryDist.map(s => s.count),
        backgroundColor: [
          '#93c5fd',
          '#60a5fa',
          '#3b82f6',
          '#8b5cf6',
          '#7c3aed'
        ],
        borderRadius: 6,
      }
    ]
  };

  // 4. Academic Placement Trend (Line Chart)
  const trendLineData = {
    labels: ['2021-22', '2022-23', '2023-24', '2024-25 (Current)'],
    datasets: [
      {
        label: 'Placement Conversion Rate (%)',
        data: [68.4, 72.1, 75.8, stats.placementRate],
        borderColor: '#4f46e5',
        backgroundColor: 'rgba(79, 70, 229, 0.08)',
        fill: true,
        tension: 0.35,
        pointBackgroundColor: '#4f46e5',
        pointRadius: 5,
      },
      {
        label: 'Average Package (LPA)',
        data: [6.8, 7.4, 8.1, stats.avgSalary],
        borderColor: '#06b6d4',
        borderDash: [5, 5],
        tension: 0.3,
        pointBackgroundColor: '#06b6d4',
        pointRadius: 4,
      }
    ]
  };

  // 5. Top 5 Hiring Companies
  const topCompanies = companyStats.slice(0, 5);

  return (
    <div className="space-y-8 pb-12">
      {/* 6 Required Summary KPI Cards (Section 3.B) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Card 1: Total number of students */}
        <StatCard
          title="Total Students"
          value={stats.totalStudents}
          subtitle="Enrolled Cohort"
          icon={Users}
          iconBgColor="bg-blue-50"
          iconTextColor="text-blue-600"
          rFormula="n()"
        />

        {/* Card 2: Total students placed */}
        <StatCard
          title="Students Placed"
          value={stats.placedStudents}
          subtitle="Offers Confirmed"
          icon={CheckCircle2}
          iconBgColor="bg-emerald-50"
          iconTextColor="text-emerald-600"
          trend="+5 offers"
          trendPositive={true}
          rFormula="sum(Status == 'Placed')"
        />

        {/* Card 3: Total students not placed */}
        <StatCard
          title="Not Placed"
          value={stats.unplacedStudents}
          subtitle="Seeking Placement"
          icon={XCircle}
          iconBgColor="bg-rose-50"
          iconTextColor="text-rose-600"
          rFormula="sum(Status == 'Unplaced')"
        />

        {/* Card 4: Overall placement percentage */}
        <StatCard
          title="Placement Rate"
          value={`${stats.placementRate}%`}
          subtitle="Conversion Ratio"
          icon={TrendingUp}
          iconBgColor="bg-indigo-50"
          iconTextColor="text-indigo-600"
          trend="Target: 75%"
          trendPositive={stats.placementRate >= 75}
          rFormula="mean(Status) * 100"
        />

        {/* Card 5: Average package (LPA) */}
        <StatCard
          title="Average Package"
          value={`₹${stats.avgSalary}`}
          subtitle="Annual CTC (LPA)"
          icon={DollarSign}
          iconBgColor="bg-purple-50"
          iconTextColor="text-purple-600"
          trend={`Med: ₹${stats.medianSalary}`}
          rFormula="mean(SalaryPackage)"
        />

        {/* Card 6: Highest package (LPA) */}
        <StatCard
          title="Highest Package"
          value={`₹${stats.highestSalary}`}
          subtitle="Top Annual CTC"
          icon={Award}
          iconBgColor="bg-amber-50"
          iconTextColor="text-amber-600"
          trend="Tier-1 Offer"
          rFormula="max(SalaryPackage)"
        />
      </div>

      {/* Row 2: Department-wise Placement Rates + Placed vs Not Placed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Department Performance Bar Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Department-Wise Placement Performance</h3>
              <p className="text-xs text-slate-500">Placement percentage and normalized average CGPA by academic department</p>
            </div>
            <span className="text-[11px] font-mono text-indigo-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
              ggplot2 geom_bar()
            </span>
          </div>
          <div className="h-72">
            <Bar 
              data={deptChartData} 
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } },
                  tooltip: {
                    callbacks: {
                      label: (context) => {
                        return `${context.dataset.label}: ${context.raw}`;
                      }
                    }
                  }
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: '#f1f5f9' },
                    ticks: { font: { size: 10 } }
                  },
                  x: {
                    grid: { display: false },
                    ticks: { font: { size: 10 } }
                  }
                }
              }} 
            />
          </div>
        </div>

        {/* Right: Placed vs Not Placed Doughnut */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-slate-900 text-base">Placement Ratio</h3>
              <span className="text-[11px] font-mono text-indigo-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                prop.table()
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-4">Ratio of placed students to students seeking recruitment</p>
            <div className="h-52 relative flex items-center justify-center">
              <Doughnut 
                data={statusDoughnutData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  cutout: '72%',
                  plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } }
                  }
                }}
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-6">
                <span className="text-2xl font-extrabold text-slate-900">{stats.placementRate}%</span>
                <span className="text-[10px] text-slate-400 font-medium">Placed</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-center text-xs">
            <div className="p-2 bg-blue-50/70 rounded-lg">
              <div className="text-slate-500 text-[11px]">Placed</div>
              <div className="font-bold text-blue-700 text-sm">{stats.placedStudents} Candidates</div>
            </div>
            <div className="p-2 bg-slate-100/70 rounded-lg">
              <div className="text-slate-500 text-[11px]">Unplaced</div>
              <div className="font-bold text-slate-700 text-sm">{stats.unplacedStudents} Candidates</div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Salary Distribution + Yearly Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Salary Bracket Histogram */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Salary Package Distribution (LPA)</h3>
              <p className="text-xs text-slate-500">Number of student job offers grouped by compensation tier</p>
            </div>
            <span className="text-[11px] font-mono text-indigo-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
              cut() & hist()
            </span>
          </div>
          <div className="h-64">
            <Bar
              data={salaryChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false }
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    grid: { color: '#f1f5f9' },
                    ticks: { precision: 0 }
                  },
                  x: {
                    grid: { display: false }
                  }
                }
              }}
            />
          </div>
        </div>

        {/* Multi-Year Academic Placement Trajectory */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Historical Placement & CTC Trajectory</h3>
              <p className="text-xs text-slate-500">Progression of placement percentage and average compensation</p>
            </div>
            <span className="text-[11px] font-mono text-indigo-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
              geom_line()
            </span>
          </div>
          <div className="h-64">
            <Line
              data={trendLineData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } }
                },
                scales: {
                  y: {
                    beginAtZero: false,
                    min: 0,
                    max: 100,
                    grid: { color: '#f1f5f9' }
                  },
                  x: {
                    grid: { display: false }
                  }
                }
              }}
            />
          </div>
        </div>
      </div>

      {/* Row 4: Top Recruiting Companies Snapshot */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Top Institutional Recruiters</h3>
              <p className="text-xs text-slate-500">Leading companies by hiring volume and average package offered</p>
            </div>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {companyStats.length} Unique Corporate Partners
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {topCompanies.map((c, index) => (
            <div key={c.company} className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 font-mono">#0{index + 1}</span>
                <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {c.tier}
                </span>
              </div>
              <h4 className="font-bold text-slate-900 text-sm">{c.company}</h4>
              <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs">
                <span className="text-slate-600">{c.count} Hires</span>
                <span className="font-bold text-slate-900">₹{c.avgPackage} LPA</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
