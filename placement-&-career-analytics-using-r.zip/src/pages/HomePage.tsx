import React from 'react';
import { 
  ArrowRight, 
  BarChart3, 
  BrainCircuit, 
  FileCode, 
  GraduationCap, 
  TrendingUp, 
  Users, 
  Award, 
  CheckCircle2, 
  Database,
  Briefcase
} from 'lucide-react';
import { ActiveTab } from '../components/Sidebar';
import { SummaryStats } from '../types';

interface HomePageProps {
  stats: SummaryStats;
  onNavigate: (tab: ActiveTab) => void;
  onOpenRModal: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  stats,
  onNavigate,
  onOpenRModal
}) => {
  return (
    <div className="space-y-10 pb-12">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-900 text-white p-8 sm:p-12 border border-slate-800 shadow-xl">
        {/* Subtle geometric background overlay */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#818cf8_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
            <GraduationCap className="w-3.5 h-3.5 text-indigo-300" />
            <span>Final Year Academic Engineering Project Presentation</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
            Placement and Career Analytics
          </h1>

          <p className="text-lg sm:text-xl text-indigo-200 font-medium">
            Student Placement Insights Powered by R Programming
          </p>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            A comprehensive analytical dashboard integrating R-based statistical inference, binomial logistic regression, and career path optimization to evaluate campus recruitment patterns, identify critical student skill gaps, and forecast placement success.
          </p>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('dashboard')}
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-md shadow-blue-500/20 transition-all flex items-center gap-2 group cursor-pointer"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => onNavigate('analytics')}
              className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm border border-white/15 backdrop-blur-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              <BarChart3 className="w-4 h-4 text-indigo-300" />
              <span>View Analytics</span>
            </button>

            <button
              onClick={() => onNavigate('prediction')}
              className="px-6 py-3 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 font-semibold text-sm border border-purple-400/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <BrainCircuit className="w-4 h-4 text-purple-300" />
              <span>Placement Predictor</span>
            </button>

            <button
              onClick={onOpenRModal}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5 text-indigo-400" />
              <span>View R Code</span>
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards Requested in Section 3.A */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Institutional Cohort Summary</h2>
            <p className="text-xs text-slate-500">Live aggregated statistics computed across all departments</p>
          </div>
          <span className="text-xs text-indigo-600 font-mono font-medium">
            R formula: summary(cohort)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Total Students */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Students</span>
              <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900 tracking-tight font-sans">
              {stats.totalStudents}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Across 6 Departments</span>
              <span className="text-slate-400 font-mono text-[11px]">n = {stats.totalStudents}</span>
            </div>
          </div>

          {/* Card 2: Students Placed */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Students Placed</span>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900 tracking-tight font-sans">
              {stats.placedStudents}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="text-rose-600 font-medium">{stats.unplacedStudents} Unplaced</span>
              <span className="text-emerald-600 font-semibold font-mono text-[11px]">Verified Offers</span>
            </div>
          </div>

          {/* Card 3: Placement Percentage */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Placement Rate</span>
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900 tracking-tight font-sans text-indigo-600">
              {stats.placementRate}%
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Benchmark: 70%</span>
              <span className="text-indigo-600 font-semibold font-mono text-[11px]">+8.2% vs 2024</span>
            </div>
          </div>

          {/* Card 4: Average Salary */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-all">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Average Salary</span>
              <div className="p-2.5 rounded-xl bg-purple-50 text-purple-600">
                <Award className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-extrabold text-slate-900 tracking-tight font-sans">
              ₹{stats.avgSalary} <span className="text-base font-medium text-slate-500">LPA</span>
            </div>
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Max: ₹{stats.highestSalary} LPA</span>
              <span className="text-purple-600 font-mono text-[11px]">Med: ₹{stats.medianSalary} LPA</span>
            </div>
          </div>
        </div>
      </div>

      {/* R Analytical Pipeline Flow */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs">
        <div className="max-w-2xl mb-6">
          <h3 className="text-base sm:text-lg font-bold text-slate-900">
            Statistical Analysis Pipeline Architecture
          </h3>
          <p className="text-xs sm:text-sm text-slate-500">
            How R packages process raw student data into actionable placement intelligence:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
              01
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Data Ingestion & Cleaning</h4>
            <p className="text-xs text-slate-500">
              Standardizes academic scores, normalizes scale variations, and validates missing values using <code className="text-indigo-600 font-mono">tidyr</code>.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
              02
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Descriptive Analytics</h4>
            <p className="text-xs text-slate-500">
              Calculates department-wise means, standard deviations, and salary distributions using <code className="text-indigo-600 font-mono">dplyr</code>.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs">
              03
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Logistic Regression</h4>
            <p className="text-xs text-slate-500">
              Fits binomial generalized linear model <code className="text-indigo-600 font-mono">glm()</code> to estimate placement odds ratios and probabilities.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
              04
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Career Roadmapping</h4>
            <p className="text-xs text-slate-500">
              Maps candidate strengths to in-demand profiles, highlighting skill gaps and targeted upskilling certifications.
            </p>
          </div>
        </div>
      </div>

      {/* Feature Deep Dive Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
          <div className="p-3 w-fit rounded-xl bg-blue-50 text-blue-600">
            <Database className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-base">Comprehensive Student Records</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Manage student records with full CRUD operations. Search, filter by department or placement status, and inspect individual academic credentials.
          </p>
          <button 
            onClick={() => onNavigate('students')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 pt-1 cursor-pointer"
          >
            <span>Manage Records</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
          <div className="p-3 w-fit rounded-xl bg-purple-50 text-purple-600">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-base">ML Placement Predictor</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Input CGPA, aptitude, communication scores, and internships to evaluate placement likelihood with calibrated logistic regression and factor contribution.
          </p>
          <button 
            onClick={() => onNavigate('prediction')}
            className="text-xs font-semibold text-purple-600 hover:text-purple-800 flex items-center gap-1 pt-1 cursor-pointer"
          >
            <span>Try Predictor</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
          <div className="p-3 w-fit rounded-xl bg-emerald-50 text-emerald-600">
            <Briefcase className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-900 text-base">Career Analytics & Skill Gaps</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Benchmark students against Software Developer, Data Analyst, Web Developer, and Core roles. Get tailored action plans and certification targets.
          </p>
          <button 
            onClick={() => onNavigate('career')}
            className="text-xs font-semibold text-emerald-600 hover:text-emerald-800 flex items-center gap-1 pt-1 cursor-pointer"
          >
            <span>Explore Career Paths</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
