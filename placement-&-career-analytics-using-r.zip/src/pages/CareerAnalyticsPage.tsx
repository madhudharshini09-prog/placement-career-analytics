import React, { useState, useMemo } from 'react';
import { 
  Compass, 
  CheckCircle2, 
  AlertCircle, 
  BookOpen, 
  Award, 
  TrendingUp, 
  Search, 
  UserCheck, 
  ArrowRight,
  Briefcase
} from 'lucide-react';
import { 
  evaluateCareerPaths, 
  getInDemandSkillsAnalysis 
} from '../services/careerRecommendationService';
import { Student } from '../types';

interface CareerAnalyticsPageProps {
  students: Student[];
}

export const CareerAnalyticsPage: React.FC<CareerAnalyticsPageProps> = ({ students }) => {
  // Analyze in-demand skills
  const inDemandSkills = useMemo(() => getInDemandSkillsAnalysis(students), [students]);

  // Selected student for personalized career pathway
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');

  const activeStudent = useMemo(() => {
    return students.find(s => s.id === selectedStudentId) || students[0];
  }, [students, selectedStudentId]);

  // Calculate career path recommendations for active student
  const recommendations = useMemo(() => {
    if (!activeStudent) return [];
    return evaluateCareerPaths(
      activeStudent.technicalSkills,
      activeStudent.cgpa,
      activeStudent.aptitudeScore,
      activeStudent.communicationScore
    );
  }, [activeStudent]);

  const topMatch = recommendations[0];

  return (
    <div className="space-y-8 pb-12">
      {/* Overview Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Career Analytics & Skill Gap Optimization</h3>
            <p className="text-xs text-slate-500">
              Evaluates individual student capabilities against industry hiring benchmarks and maps customized learning trajectories
            </p>
          </div>

          {/* Student Selector */}
          <div className="flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-semibold text-slate-700">Select Candidate:</span>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500 max-w-[200px]"
            >
              {students.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.department.replace('Engineering', '')}) - {s.cgpa}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Active Candidate Profile Card */}
      {activeStudent && (
        <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100 shadow-2xs">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-white border border-indigo-200 text-indigo-800">
                  {activeStudent.id}
                </span>
                <span className="text-xs text-slate-500 font-medium">{activeStudent.department}</span>
              </div>
              <h2 className="text-2xl font-extrabold text-slate-900">{activeStudent.name}</h2>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-700 pt-1">
                <span><strong>CGPA:</strong> {activeStudent.cgpa}</span>
                <span>•</span>
                <span><strong>Aptitude:</strong> {activeStudent.aptitudeScore}/100</span>
                <span>•</span>
                <span><strong>Communication:</strong> {activeStudent.communicationScore}/100</span>
                <span>•</span>
                <span><strong>Internships:</strong> {activeStudent.internshipExperience} Months</span>
              </div>
            </div>

            {/* Top Recommended Match Badge */}
            {topMatch && (
              <div className="p-4 bg-white rounded-xl border border-indigo-100 shadow-xs flex items-center gap-4 min-w-[280px]">
                <div className="p-3 rounded-lg bg-indigo-600 text-white">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-[11px] uppercase font-bold text-indigo-600 tracking-wider">Top Career Match</div>
                  <div className="font-bold text-slate-900 text-sm">{topMatch.roleTitle}</div>
                  <div className="text-xs text-emerald-600 font-semibold">{topMatch.matchScore}% Compatibility</div>
                </div>
              </div>
            )}
          </div>

          {/* Current Skills Chips */}
          <div className="mt-4 pt-4 border-t border-indigo-100/80 flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Verified Technical Skills:</span>
            {activeStudent.technicalSkills.map(skill => (
              <span 
                key={skill}
                className="px-2.5 py-1 text-xs font-medium bg-white text-indigo-900 rounded-lg border border-indigo-200/80 shadow-2xs"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Suitable Career Pathways Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Recommended Career Paths for {activeStudent?.name}</h3>
            <p className="text-xs text-slate-500">Benchmark scoring across six key industry trajectories</p>
          </div>
          <span className="text-xs text-slate-500 font-mono">Weighted Algorithm (Skills 60% + CGPA 20% + Apt 20%)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {recommendations.map(path => {
            const isHigh = path.suitability === 'High';
            const isMed = path.suitability === 'Medium';

            return (
              <div 
                key={path.roleTitle}
                className={`bg-white rounded-2xl p-5 border transition-all flex flex-col justify-between ${
                  isHigh 
                    ? 'border-indigo-300 shadow-sm ring-1 ring-indigo-200' 
                    : 'border-slate-200/90 shadow-2xs hover:shadow-xs'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{path.roleTitle}</h4>
                      <p className="text-xs text-slate-500 font-mono">Typical Entry CTC: {path.averageEntryLPA}</p>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                      isHigh 
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                        : isMed 
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}>
                      {path.matchScore}% Match
                    </span>
                  </div>

                  {/* Matching Skills */}
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Matching Competencies ({path.matchingSkills.length})</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {path.matchingSkills.length > 0 ? (
                        path.matchingSkills.map(s => (
                          <span key={s} className="px-2 py-0.5 text-[10px] font-medium bg-emerald-50 text-emerald-800 rounded">
                            {s}
                          </span>
                        ))
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">No direct skill matches</span>
                      )}
                    </div>
                  </div>

                  {/* Skill Gaps */}
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                      <span>Identified Skill Gaps ({path.missingSkills.length})</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {path.missingSkills.length > 0 ? (
                        path.missingSkills.map(s => (
                          <span key={s} className="px-2 py-0.5 text-[10px] font-medium bg-rose-50 text-rose-700 rounded border border-rose-100">
                            + {s}
                          </span>
                        ))
                      ) : (
                        <span className="text-[11px] text-emerald-600 font-medium">All core requirements met!</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Suggested Action Plan */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                  <div className="font-semibold text-slate-700 text-[11px]">Recommended Upskilling Steps:</div>
                  {path.actionPlan.slice(0, 2).map((action, i) => (
                    <div key={i} className="flex items-start gap-1.5 text-[11px] leading-tight text-slate-500">
                      <span className="text-indigo-600 font-bold shrink-0">•</span>
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* In-Demand Technical Skills Market Analysis */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">In-Demand Technical Skills Market Analysis</h3>
              <p className="text-xs text-slate-500">Placement conversion rate and average salary package associated with each competency</p>
            </div>
          </div>
          <span className="text-xs font-mono text-indigo-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
            R table() & aggregate()
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {inDemandSkills.slice(0, 12).map(skill => (
            <div key={skill.skill} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 text-xs">{skill.skill}</span>
                <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                  skill.demandTier === 'High Value Tier' 
                    ? 'bg-purple-100 text-purple-700' 
                    : 'bg-blue-100 text-blue-700'
                }`}>
                  {skill.demandTier}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-200/60">
                <span className="text-slate-500">{skill.studentCount} candidates</span>
                <span className="font-semibold text-emerald-600">{skill.placementRate}% Placed</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span className="text-[11px] text-slate-400">Avg CTC:</span>
                <span className="font-mono font-bold text-slate-900">₹{skill.avgSalary} LPA</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
