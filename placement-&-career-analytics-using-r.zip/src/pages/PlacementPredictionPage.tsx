import React, { useState } from 'react';
import { 
  BrainCircuit, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  Code, 
  RotateCcw, 
  Gauge, 
  Sliders, 
  TrendingUp,
  FileCode2,
  ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { AVAILABLE_SKILLS, DEPARTMENTS } from '../data/studentsData';
import { generateReproducibleRScript, predictPlacement } from '../services/rAnalyticsService';
import { PredictionInput, PredictionResult } from '../types';

interface PlacementPredictionPageProps {
  onOpenRModalWithCode: (code: string, title: string) => void;
}

export const PlacementPredictionPage: React.FC<PlacementPredictionPageProps> = ({
  onOpenRModalWithCode
}) => {
  const [input, setInput] = useState<PredictionInput>({
    cgpa: 8.2,
    aptitudeScore: 82,
    communicationScore: 85,
    internshipExperience: 3,
    technicalSkills: ['Python', 'SQL', 'Data Structures', 'Git'],
    department: 'Computer Science'
  });

  const [result, setResult] = useState<PredictionResult | null>(() => predictPlacement({
    cgpa: 8.2,
    aptitudeScore: 82,
    communicationScore: 85,
    internshipExperience: 3,
    technicalSkills: ['Python', 'SQL', 'Data Structures', 'Git']
  }));

  const handlePredict = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const prediction = predictPlacement(input);
    setResult(prediction);

    if (prediction.probability >= 75) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    }
  };

  const handlePreset = (preset: 'high' | 'avg' | 'risk') => {
    let presetInput: PredictionInput;
    if (preset === 'high') {
      presetInput = {
        cgpa: 9.1,
        aptitudeScore: 92,
        communicationScore: 90,
        internshipExperience: 6,
        technicalSkills: ['Python', 'Data Structures', 'React', 'SQL', 'Machine Learning', 'AWS'],
        department: 'Computer Science'
      };
    } else if (preset === 'avg') {
      presetInput = {
        cgpa: 7.6,
        aptitudeScore: 72,
        communicationScore: 75,
        internshipExperience: 2,
        technicalSkills: ['Java', 'SQL', 'Git'],
        department: 'Information Technology'
      };
    } else {
      presetInput = {
        cgpa: 6.4,
        aptitudeScore: 56,
        communicationScore: 58,
        internshipExperience: 0,
        technicalSkills: ['C++'],
        department: 'Mechanical Engineering'
      };
    }
    setInput(presetInput);
    setResult(predictPlacement(presetInput));
  };

  const toggleSkill = (skill: string) => {
    const current = input.technicalSkills;
    if (current.includes(skill)) {
      setInput({ ...input, technicalSkills: current.filter(s => s !== skill) });
    } else {
      setInput({ ...input, technicalSkills: [...current, skill] });
    }
  };

  const handleViewRScript = () => {
    const script = generateReproducibleRScript(input);
    onOpenRModalWithCode(script, 'R Logistic Regression Code for Current Candidate');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-slate-900 text-base">R Statistical Placement Likelihood Predictor</h3>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Binomial GLM / Logistic Regression
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Calculated using calibrated maximum likelihood beta coefficients from R's <code className="text-indigo-600 font-mono">glm(family = binomial)</code>
          </p>
        </div>

        {/* Preset quick buttons */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-medium">Test Profiles:</span>
          <button
            type="button"
            onClick={() => handlePreset('high')}
            className="px-2.5 py-1 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 font-medium transition-colors cursor-pointer"
          >
            Tier-1 Profile
          </button>
          <button
            type="button"
            onClick={() => handlePreset('avg')}
            className="px-2.5 py-1 rounded bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-medium transition-colors cursor-pointer"
          >
            Average Profile
          </button>
          <button
            type="button"
            onClick={() => handlePreset('risk')}
            className="px-2.5 py-1 rounded bg-rose-50 text-rose-700 hover:bg-rose-100 font-medium transition-colors cursor-pointer"
          >
            At-Risk Profile
          </button>
        </div>
      </div>

      {/* Model Disclaimer Notice Requested in Section 3.F */}
      <div className="p-4 bg-amber-50/80 border border-amber-200/80 rounded-xl flex items-start gap-3 text-xs text-amber-900">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-amber-900">Statistical Estimation Disclaimer & Architecture Transparency</div>
          <p className="text-amber-800 leading-relaxed">
            Predictions displayed here are mathematical probability estimations derived from an empirical Binomial Logistic Regression model (<code className="font-mono text-xs font-semibold">stats::glm</code>) and decision rules (<code className="font-mono text-xs font-semibold">rpart</code>). They are <strong>probabilistic estimates and do not represent a guaranteed placement outcome</strong>. Individual company interview rounds, soft skills, and market conditions vary.
          </p>
        </div>
      </div>

      {/* Main Grid: Form Inputs (Left) and Prediction Analysis (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Input Form (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-600" />
              <h4 className="font-bold text-slate-900 text-sm">Candidate Metrics Input</h4>
            </div>
            <button
              type="button"
              onClick={() => handlePreset('avg')}
              className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          <form onSubmit={handlePredict} className="space-y-5">
            {/* Department */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Candidate Department
              </label>
              <select
                value={input.department}
                onChange={e => setInput({ ...input, department: e.target.value as any })}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                {DEPARTMENTS.map(d => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>

            {/* CGPA Slider & Number */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  Cumulative GPA (CGPA: 0.0 - 10.0)
                </label>
                <span className="font-mono font-bold text-blue-600 text-sm bg-blue-50 px-2 py-0.5 rounded">
                  {input.cgpa.toFixed(2)}
                </span>
              </div>
              <input
                type="range"
                min="5.0"
                max="10.0"
                step="0.05"
                value={input.cgpa}
                onChange={e => setInput({ ...input, cgpa: parseFloat(e.target.value) })}
                className="w-full accent-blue-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>5.0 (Pass)</span>
                <span>7.5 (Eligibility)</span>
                <span>10.0 (Perfect)</span>
              </div>
            </div>

            {/* Aptitude Assessment Score */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  Aptitude Assessment Score (0 - 100)
                </label>
                <span className="font-mono font-bold text-indigo-600 text-sm bg-indigo-50 px-2 py-0.5 rounded">
                  {input.aptitudeScore} / 100
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="100"
                step="1"
                value={input.aptitudeScore}
                onChange={e => setInput({ ...input, aptitudeScore: parseInt(e.target.value) })}
                className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>30</span>
                <span>65 (Cutoff)</span>
                <span>100</span>
              </div>
            </div>

            {/* Communication Score */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  Communication Score (0 - 100)
                </label>
                <span className="font-mono font-bold text-purple-600 text-sm bg-purple-50 px-2 py-0.5 rounded">
                  {input.communicationScore} / 100
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="100"
                step="1"
                value={input.communicationScore}
                onChange={e => setInput({ ...input, communicationScore: parseInt(e.target.value) })}
                className="w-full accent-purple-600 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
            </div>

            {/* Internship Experience */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-700">
                  Internship Experience (Months)
                </label>
                <span className="font-mono font-bold text-slate-800 text-sm bg-slate-100 px-2 py-0.5 rounded">
                  {input.internshipExperience} Months
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="12"
                step="1"
                value={input.internshipExperience}
                onChange={e => setInput({ ...input, internshipExperience: parseInt(e.target.value) })}
                className="w-full accent-slate-800 cursor-pointer h-2 bg-slate-100 rounded-lg"
              />
            </div>

            {/* Technical Skills Multiselect */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Technical Stack & Tools ({input.technicalSkills.length} selected)
              </label>
              <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 bg-slate-50 border border-slate-200 rounded-lg">
                {AVAILABLE_SKILLS.slice(0, 15).map(skill => {
                  const selected = input.technicalSkills.includes(skill);
                  return (
                    <button
                      key={skill}
                      type="button"
                      onClick={() => toggleSkill(skill)}
                      className={`px-2 py-0.5 text-[11px] rounded transition-all cursor-pointer ${
                        selected
                          ? 'bg-blue-600 text-white font-medium shadow-2xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {skill} {selected && '✓'}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <BrainCircuit className="w-4 h-4" />
                <span>Calculate Placement Likelihood</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Model Result & Diagnostic Factors (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {result && (
            <>
              {/* Prediction Probability Gauge Card */}
              <div className={`p-6 rounded-2xl border transition-all ${
                result.probability >= 75
                  ? 'bg-gradient-to-br from-blue-50 via-indigo-50 to-emerald-50 border-emerald-200 shadow-sm'
                  : result.probability >= 45
                  ? 'bg-gradient-to-br from-blue-50 via-amber-50 to-yellow-50 border-amber-200 shadow-sm'
                  : 'bg-gradient-to-br from-slate-50 via-rose-50 to-red-50 border-rose-200 shadow-sm'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono">
                      R Statistical Inference Result
                    </span>
                    <h3 className="text-xl font-extrabold text-slate-900">
                      {result.status}
                    </h3>
                    <p className="text-xs text-slate-600">
                      Odds Ratio: <strong className="font-mono text-indigo-700">{result.oddsRatio}x</strong> · 95% Confidence Interval: [{result.confidenceInterval[0]}% - {result.confidenceInterval[1]}%]
                    </p>
                  </div>

                  {/* Percentage Metric */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight font-sans">
                        {result.probability}%
                      </div>
                      <div className="text-[11px] text-slate-500 font-medium">Placement Probability</div>
                    </div>
                  </div>
                </div>

                {/* Progress Bar Gauge */}
                <div className="mt-4 w-full bg-white/80 rounded-full h-3 border border-slate-200 overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-700 ${
                      result.probability >= 75
                        ? 'bg-gradient-to-r from-blue-600 to-emerald-500'
                        : result.probability >= 45
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-400'
                        : 'bg-gradient-to-r from-rose-500 to-red-600'
                    }`}
                    style={{ width: `${result.probability}%` }}
                  />
                </div>
              </div>

              {/* Factors Influencing Prediction (Required in Section 3.F) */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-sm">Key Contributing Factors (Log-Odds Impact)</h4>
                  <span className="text-xs font-mono text-slate-400">R glm::coef(model)</span>
                </div>

                <div className="space-y-3">
                  {result.factors.map((f, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-800">{f.name}</span>
                        <span className={`px-2 py-0.5 rounded font-mono text-[11px] font-bold ${
                          f.impact === 'positive' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : f.impact === 'neutral'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {f.weight > 0 ? `+${f.weight}` : f.weight} logit
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-relaxed">{f.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actionable Recommendations */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <h4 className="font-bold text-slate-900 text-sm">Actionable Employability Steps</h4>
                <div className="space-y-2">
                  {result.recommendations.map((rec, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-slate-600">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* View Equivalent R Code Trigger */}
              <div className="bg-slate-900 text-slate-200 p-4 rounded-2xl flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-500/20 text-indigo-300 rounded-lg">
                    <FileCode2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-white">Reproduce in RStudio / Plumber</div>
                    <p className="text-[11px] text-slate-400">View and copy the exact R script used for this candidate's logistic regression model</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleViewRScript}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>View R Code</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
