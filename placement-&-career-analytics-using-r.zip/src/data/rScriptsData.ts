export interface RScriptItem {
  id: string;
  name: string;
  description: string;
  packages: string[];
  filename: string;
  code: string;
}

export const R_SCRIPTS: RScriptItem[] = [
  {
    id: 'data-cleaning-eda',
    name: '1. Data Cleaning & Exploratory Data Analysis (EDA)',
    description: 'Data ingestion, schema transformation, missing value handling, and descriptive statistical metrics using dplyr and tidyr.',
    packages: ['dplyr', 'tidyr', 'readr', 'psych'],
    filename: '01_data_cleaning_eda.R',
    code: `# ==============================================================================
# Script 01: Data Cleaning & Exploratory Data Analysis (EDA)
# Project: Placement and Career Analytics using R Programming
# Author: Academic Project Team
# ==============================================================================

# 1. Install & Load Required CRAN Packages
required_packages <- c("dplyr", "tidyr", "readr", "psych", "summarytools")
new_packages <- required_packages[!(required_packages %in% installed.packages()[, "Package"])]
if(length(new_packages)) install.packages(new_packages)

library(dplyr)
library(tidyr)
library(readr)
library(psych)

# 2. Ingest Placement Records CSV
placement_data <- read_csv("placement_dataset.csv", col_types = cols())

# 3. Data Cleaning & Validation
cleaned_data <- placement_data %>%
  # Filter out erroneous negative scores or outliers
  filter(CGPA >= 0 & CGPA <= 10) %>%
  filter(AptitudeScore >= 0 & AptitudeScore <= 100) %>%
  filter(CommunicationScore >= 0 & CommunicationScore <= 100) %>%
  # Standardize categorical variables into factors
  mutate(
    Department = as.factor(Department),
    PlacementStatus = as.factor(PlacementStatus),
    Gender = as.factor(Gender),
    Placed_Binary = ifelse(PlacementStatus == "Placed", 1, 0),
    Salary_Clean = ifelse(is.na(SalaryPackage) | PlacementStatus == "Not Placed", 0, SalaryPackage)
  )

# Check structure and missing values
glimpse(cleaned_data)
cat("Missing values in dataset: \\n")
colSums(is.na(cleaned_data))

# 4. Statistical Summary Metrics
cat("\\n--- Overall Academic & Placement Statistics ---\\n")
describe(cleaned_data %>% select(CGPA, AptitudeScore, CommunicationScore, InternshipExperience, Salary_Clean))

# 5. Department-wise Aggregations using dplyr
department_kpi <- cleaned_data %>%
  group_by(Department) %>%
  summarise(
    Total_Students = n(),
    Placed_Count = sum(Placed_Binary),
    Placement_Rate_Pct = round((Placed_Count / Total_Students) * 100, 2),
    Mean_CGPA = round(mean(CGPA), 2),
    Median_CGPA = round(median(CGPA), 2),
    Mean_Salary_LPA = round(mean(Salary_Clean[Salary_Clean > 0]), 2),
    Max_Salary_LPA = round(max(Salary_Clean), 2),
    StdDev_Salary = round(sd(Salary_Clean[Salary_Clean > 0]), 2)
  ) %>%
  arrange(desc(Placement_Rate_Pct))

print(department_kpi)

# 6. Save Cleaned Dataset for Model Training
write_csv(cleaned_data, "cleaned_placement_data.csv")
cat("\\n[SUCCESS] Cleaned data successfully written to cleaned_placement_data.csv\\n")
`
  },
  {
    id: 'ggplot2-visualizations',
    name: '2. Publication-Ready Visualizations (ggplot2)',
    description: 'Generates professional placement distribution charts, department comparisons, and correlation scatter plots.',
    packages: ['ggplot2', 'corrplot', 'gridExtra', 'scales'],
    filename: '02_ggplot2_visualizations.R',
    code: `# ==============================================================================
# Script 02: Publication-Ready Visualizations with ggplot2
# Project: Placement and Career Analytics using R Programming
# ==============================================================================

library(ggplot2)
library(dplyr)
library(scales)
library(corrplot)

# Load Cleaned Data
data <- read.csv("cleaned_placement_data.csv")

# Custom Clean Dashboard Theme
theme_academic <- theme_minimal(base_size = 13) +
  theme(
    plot.title = element_text(face = "bold", color = "#1e293b", size = 15, margin = margin(b = 8)),
    plot.subtitle = element_text(color = "#64748b", size = 11, margin = margin(b = 15)),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "#e2e8f0"),
    axis.title = element_text(face = "bold", color = "#475569"),
    axis.text = element_text(color = "#334155"),
    legend.position = "bottom"
  )

# Chart 1: Department-wise Placement Conversion Rates
p1 <- ggplot(data, aes(x = reorder(Department, -Placed_Binary), fill = PlacementStatus)) +
  geom_bar(position = "fill", alpha = 0.9) +
  scale_y_continuous(labels = scales::percent_format()) +
  scale_fill_manual(values = c("Not Placed" = "#cbd5e1", "Placed" = "#3b82f6")) +
  coord_flip() +
  labs(
    title = "Department-wise Placement Conversion Ratio",
    subtitle = "Proportion of placed vs unplaced final-year engineering students",
    x = "Academic Department",
    y = "Percentage of Cohort",
    fill = "Placement Status"
  ) +
  theme_academic

ggsave("plot_department_placement.png", p1, width = 8, height = 5, dpi = 300)

# Chart 2: CGPA vs Salary Package with Placement Sigmoid
p2 <- ggplot(filter(data, PlacementStatus == "Placed"), aes(x = CGPA, y = Salary_Clean, color = Department)) +
  geom_point(aes(size = InternshipExperience), alpha = 0.8) +
  geom_smooth(method = "lm", se = TRUE, color = "#7c3aed", fill = "#ddd6fe", linetype = "dashed") +
  scale_y_continuous(labels = function(x) paste0(x, " LPA")) +
  labs(
    title = "Salary Package Distribution vs CGPA",
    subtitle = "Size of point indicates internship duration in months",
    x = "Cumulative Grade Point Average (CGPA)",
    y = "Offered Salary Package (LPA)",
    size = "Internship (Mo)"
  ) +
  theme_academic

ggsave("plot_cgpa_salary_regression.png", p2, width = 9, height = 5.5, dpi = 300)

# Chart 3: Correlation Matrix Heatmap
numeric_cols <- data %>% select(CGPA, AptitudeScore, CommunicationScore, InternshipExperience, Placed_Binary, Salary_Clean)
corr_matrix <- cor(numeric_cols, use = "complete.obs")

png("plot_correlation_matrix.png", width = 800, height = 800, res = 150)
corrplot(
  corr_matrix, 
  method = "color", 
  type = "upper", 
  addCoef.col = "black", 
  tl.col = "#1e293b", 
  tl.srt = 45,
  col = colorRampPalette(c("#ef4444", "#ffffff", "#2563eb"))(200),
  title = "\\nPearson Correlation Matrix (Placement Metrics)"
)
dev.off()

cat("[SUCCESS] All analytical figures exported to PNG successfully.\\n")
`
  },
  {
    id: 'logistic-regression-ml',
    name: '3. Machine Learning Placement Model (caret & glm)',
    description: 'Trains Binomial Logistic Regression & Decision Tree models, evaluates ROC AUC, and computes Odds Ratios with confidence intervals.',
    packages: ['caret', 'rpart', 'rpart.plot', 'pROC'],
    filename: '03_machine_learning_model.R',
    code: `# ==============================================================================
# Script 03: Machine Learning Classification Model for Placement Prediction
# Project: Placement and Career Analytics using R Programming
# ==============================================================================

library(caret)
library(pROC)
library(rpart)
library(rpart.plot)

# 1. Load Preprocessed Data
df <- read.csv("cleaned_placement_data.csv")
df$PlacementStatus <- as.factor(df$PlacementStatus)

# 2. Partition Data (80% Train, 20% Test) with Seed for Reproducibility
set.seed(42)
trainIndex <- createDataPartition(df$PlacementStatus, p = 0.80, list = FALSE)
train_data <- df[trainIndex, ]
test_data  <- df[-trainIndex, ]

cat("Training Set Size: ", nrow(train_data), " students\\n")
cat("Testing Set Size:  ", nrow(test_data), " students\\n\\n")

# 3. Train Binomial Logistic Regression Model
logit_model <- glm(
  PlacementStatus ~ CGPA + AptitudeScore + CommunicationScore + InternshipExperience,
  data = train_data,
  family = binomial(link = "logit")
)

# Model Summary & Diagnostics
summary(logit_model)

# Odds Ratios and 95% Confidence Intervals
cat("\\n--- Model Odds Ratios (Effect Size) ---\\n")
exp_coef <- exp(cbind(OddsRatio = coef(logit_model), confint(logit_model)))
print(round(exp_coef, 3))

# 4. Model Evaluation on Test Dataset
test_probs <- predict(logit_model, newdata = test_data, type = "response")
test_preds <- ifelse(test_probs >= 0.5, "Placed", "Not Placed")
test_preds <- factor(test_preds, levels = c("Not Placed", "Placed"))

cat("\\n--- Confusion Matrix & Performance Metrics ---\\n")
conf_matrix <- confusionMatrix(test_preds, test_data$PlacementStatus)
print(conf_matrix)

# 5. ROC Curve and Area Under Curve (AUC)
roc_obj <- roc(test_data$PlacementStatus, test_probs)
cat("\\nArea Under ROC Curve (AUC): ", round(auc(roc_obj), 4), "\\n")

# 6. Interpretability: Decision Tree Classifier (rpart)
tree_model <- rpart(
  PlacementStatus ~ CGPA + AptitudeScore + CommunicationScore + InternshipExperience,
  data = train_data,
  method = "class",
  control = rpart.control(cp = 0.02)
)

png("decision_tree_rules.png", width = 900, height = 700, res = 150)
rpart.plot(
  tree_model, 
  type = 4, 
  extra = 104, 
  under = TRUE, 
  box.palette = "BuPu",
  main = "Placement Decision Tree Classification Rules"
)
dev.off()

# Save Trained Model
saveRDS(logit_model, "placement_logit_model.rds")
cat("\\n[SUCCESS] Model serialized to placement_logit_model.rds\\n")
`
  },
  {
    id: 'plumber-rest-api',
    name: '4. Full-Stack Plumber REST API Server',
    description: 'Exposes microservice endpoints (/predict, /summary, /departments) using R Plumber for real-time web integration.',
    packages: ['plumber', 'jsonlite'],
    filename: '04_plumber_api.R',
    code: `# ==============================================================================
# Script 04: R Plumber REST API Server
# Exposes prediction endpoints to web applications
# Run via: plumber::pr("04_plumber_api.R") %>% plumber::pr_run(port = 8000)
# ==============================================================================

library(plumber)
library(jsonlite)

# Load serialized model trained in Script 03
if (file.exists("placement_logit_model.rds")) {
  model <- readRDS("placement_logit_model.rds")
} else {
  # Fallback training if file not found
  df <- read.csv("cleaned_placement_data.csv")
  model <- glm(
    factor(PlacementStatus) ~ CGPA + AptitudeScore + CommunicationScore + InternshipExperience,
    data = df,
    family = binomial(link = "logit")
  )
}

#* @apiTitle Placement and Career Analytics API
#* @apiDescription R backend service computing statistical placement predictions.
#* @apiVersion 1.0.0

#* Enable Cross-Origin Resource Sharing (CORS)
#* @filter cors
cors <- function(req, res) {
  res$setHeader("Access-Control-Allow-Origin", "*")
  res$setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
  res$setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization")
  if (req$REQUEST_METHOD == "OPTIONS") {
    res$status <- 200
    return(list())
  }
  plumber::forward()
}

#* Predict student placement likelihood
#* @param cgpa:numeric Candidate's cumulative GPA (0-10)
#* @param aptitude:numeric Aptitude test score (0-100)
#* @param communication:numeric Communication assessment score (0-100)
#* @param internships:numeric Duration of internships in months
#* @post /predict
function(cgpa = 8.0, aptitude = 75, communication = 75, internships = 2) {
  candidate <- data.frame(
    CGPA = as.numeric(cgpa),
    AptitudeScore = as.numeric(aptitude),
    CommunicationScore = as.numeric(communication),
    InternshipExperience = as.numeric(internships)
  )
  
  # Calculate predicted probability
  prob <- predict(model, newdata = candidate, type = "response")
  status <- ifelse(prob >= 0.5, "Placed", "Not Placed")
  
  list(
    timestamp = Sys.time(),
    input = candidate,
    prediction = list(
      probability_percentage = round(as.numeric(prob) * 100, 2),
      predicted_status = status,
      model_type = "Binomial Logistic Regression (R stats::glm)",
      confidence_level = "95% Wald Interval"
    )
  )
}

#* Health check endpoint
#* @get /health
function() {
  list(
    status = "healthy",
    engine = "R Version 4.3+ (Plumber Microservice)",
    uptime = Sys.time()
  )
}
`
  }
];
