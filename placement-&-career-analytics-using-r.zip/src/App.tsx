/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { Header } from './components/Header';
import { HomePage } from './pages/HomePage';
import { DashboardPage } from './pages/DashboardPage';
import { StudentDataPage } from './pages/StudentDataPage';
import { PlacementAnalyticsPage } from './pages/PlacementAnalyticsPage';
import { CareerAnalyticsPage } from './pages/CareerAnalyticsPage';
import { PlacementPredictionPage } from './pages/PlacementPredictionPage';
import { ReportsPage } from './pages/ReportsPage';
import { AboutProjectPage } from './pages/AboutProjectPage';
import { StudentModal } from './components/StudentModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { RCodeModal } from './components/RCodeModal';
import { RConsoleSimulator } from './components/RConsoleSimulator';
import { INITIAL_STUDENTS } from './data/studentsData';
import { computeSummaryStats, generateReproducibleRScript } from './services/rAnalyticsService';
import { Student } from './types';
import { CheckCircle2 } from 'lucide-react';

const STORAGE_KEY = 'college_placement_analytics_students_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Load students from localStorage or fallback to realistic initial records
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // ignore
    }
    return INITIAL_STUDENTS;
  });

  // Persist students on changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
    } catch {
      // ignore
    }
  }, [students]);

  // Modals state
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deletingStudent, setDeletingStudent] = useState<Student | null>(null);

  const [isRModalOpen, setIsRModalOpen] = useState(false);
  const [rModalCode, setRModalCode] = useState('');
  const [rModalTitle, setRModalTitle] = useState('R Programming Script');
  const [rModalFilename, setRModalFilename] = useState('placement_analysis.R');

  const [isRConsoleOpen, setIsRConsoleOpen] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Live Summary Stats
  const stats = useMemo(() => computeSummaryStats(students), [students]);

  // CRUD Handlers
  const handleOpenAddModal = () => {
    setEditingStudent(null);
    setIsStudentModalOpen(true);
  };

  const handleOpenEditModal = (student: Student) => {
    setEditingStudent(student);
    setIsStudentModalOpen(true);
  };

  const handleSaveStudent = (savedStudent: Student) => {
    setStudents(prev => {
      const exists = prev.some(s => s.id === savedStudent.id);
      if (exists) {
        return prev.map(s => (s.id === savedStudent.id ? savedStudent : s));
      } else {
        return [savedStudent, ...prev];
      }
    });
    setIsStudentModalOpen(false);
    showToast(editingStudent ? `Record for ${savedStudent.name} updated.` : `Added new student record for ${savedStudent.name}.`);
  };

  const handleOpenDeleteModal = (student: Student) => {
    setDeletingStudent(student);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (!deletingStudent) return;
    setStudents(prev => prev.filter(s => s.id !== deletingStudent.id));
    setIsDeleteModalOpen(false);
    showToast(`Deleted record for ${deletingStudent.name}.`);
    setDeletingStudent(null);
  };

  const handleResetData = () => {
    if (window.confirm('Reset all student placement records to default 55 verified sample records?')) {
      setStudents(INITIAL_STUDENTS);
      showToast('Sample dataset restored successfully.');
    }
  };

  // CSV Export Functionality (Section 3.G)
  const handleExportCsv = () => {
    const headers = [
      'StudentID',
      'StudentName',
      'Department',
      'CGPA',
      'TechnicalSkills',
      'AptitudeScore',
      'CommunicationScore',
      'InternshipExperienceMonths',
      'PlacementStatus',
      'CompanyName',
      'SalaryPackageLPA',
      'Gender',
      'AcademicYear'
    ];

    const rows = students.map(s => [
      `"${s.id}"`,
      `"${s.name.replace(/"/g, '""')}"`,
      `"${s.department}"`,
      s.cgpa.toFixed(2),
      `"${s.technicalSkills.join('; ')}"`,
      s.aptitudeScore,
      s.communicationScore,
      s.internshipExperience,
      `"${s.placementStatus}"`,
      `"${s.companyName.replace(/"/g, '""')}"`,
      s.salaryPackage,
      `"${s.gender}"`,
      `"${s.academicYear}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `placement_data_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Placement dataset exported as CSV.');
  };

  // Print Report Functionality (Section 3.G)
  const handlePrint = () => {
    // If not already on reports page, navigate there to print the formal document
    if (activeTab !== 'reports') {
      setActiveTab('reports');
      setTimeout(() => {
        window.print();
      }, 350);
    } else {
      window.print();
    }
  };

  // R Modal opener
  const handleOpenRModalWithCode = (code: string, title: string, filename?: string) => {
    setRModalCode(code);
    setRModalTitle(title);
    setRModalFilename(filename || 'placement_analysis.R');
    setIsRModalOpen(true);
  };

  const handleOpenDefaultRModal = () => {
    const code = generateReproducibleRScript();
    handleOpenRModalWithCode(code, 'Reproducible R Script for Current Cohort', 'placement_cohort_model.R');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans">
      {/* Toast feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-lg border border-slate-700 flex items-center gap-2 text-xs font-medium animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Responsive Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-72 transition-all">
        <Header
          activeTab={activeTab}
          onOpenSidebar={() => setIsSidebarOpen(true)}
          totalStudents={stats.totalStudents}
          placementRate={stats.placementRate}
          onExportCsv={handleExportCsv}
          onPrint={handlePrint}
          onOpenRConsole={() => setIsRConsoleOpen(true)}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'home' && (
            <HomePage
              stats={stats}
              onNavigate={setActiveTab}
              onOpenRModal={handleOpenDefaultRModal}
            />
          )}

          {activeTab === 'dashboard' && (
            <DashboardPage students={students} />
          )}

          {activeTab === 'students' && (
            <StudentDataPage
              students={students}
              onAddStudent={handleOpenAddModal}
              onEditStudent={handleOpenEditModal}
              onDeleteStudent={handleOpenDeleteModal}
              onResetData={handleResetData}
              onExportCsv={handleExportCsv}
            />
          )}

          {activeTab === 'analytics' && (
            <PlacementAnalyticsPage students={students} />
          )}

          {activeTab === 'career' && (
            <CareerAnalyticsPage students={students} />
          )}

          {activeTab === 'prediction' && (
            <PlacementPredictionPage
              onOpenRModalWithCode={handleOpenRModalWithCode}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsPage
              students={students}
              onExportCsv={handleExportCsv}
              onPrint={handlePrint}
            />
          )}

          {activeTab === 'about' && (
            <AboutProjectPage
              onOpenRModalWithCode={handleOpenRModalWithCode}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <StudentModal
        isOpen={isStudentModalOpen}
        initialData={editingStudent}
        onClose={() => setIsStudentModalOpen(false)}
        onSave={handleSaveStudent}
      />

      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        student={deletingStudent}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
      />

      <RCodeModal
        isOpen={isRModalOpen}
        onClose={() => setIsRModalOpen(false)}
        code={rModalCode}
        title={rModalTitle}
        filename={rModalFilename}
      />

      <RConsoleSimulator
        isOpen={isRConsoleOpen}
        onClose={() => setIsRConsoleOpen(false)}
        students={students}
      />
    </div>
  );
}
