import { CareerPathRecommendation, Student } from '../types';

export interface CareerRoleDefinition {
  title: string;
  category: 'Software' | 'Data Science' | 'Web' | 'Core Engineering' | 'Business';
  requiredSkills: string[];
  recommendedMinCgpa: number;
  recommendedMinAptitude: number;
  averageEntryLPA: string;
  description: string;
  learningPath: string[];
  certifications: string[];
}

export const CAREER_ROLES: CareerRoleDefinition[] = [
  {
    title: 'Software Development Engineer (SDE)',
    category: 'Software',
    requiredSkills: ['Data Structures', 'C++', 'Java', 'Python', 'SQL', 'Git'],
    recommendedMinCgpa: 7.5,
    recommendedMinAptitude: 75,
    averageEntryLPA: '12.0 - 24.0 LPA',
    description: 'Designs, develops, and maintains scalable backend architectures, distributed services, and high-performance algorithms.',
    learningPath: [
      'Master LeetCode Medium/Hard DSA patterns (Graphs, Dynamic Programming, Trees)',
      'Build a robust microservices project with Java Spring Boot or Go',
      'Learn system design fundamentals (caching, load balancing, relational vs NoSQL)'
    ],
    certifications: ['AWS Certified Developer - Associate', 'Oracle Certified Java SE Programmer']
  },
  {
    title: 'Data Analyst & BI Specialist',
    category: 'Data Science',
    requiredSkills: ['Python', 'R', 'SQL', 'Power BI', 'Tableau', 'Excel'],
    recommendedMinCgpa: 7.0,
    recommendedMinAptitude: 72,
    averageEntryLPA: '7.5 - 14.0 LPA',
    description: 'Extracts statistical patterns from institutional and enterprise databases, produces interactive dashboards, and influences product decisions.',
    learningPath: [
      'Master exploratory data analysis with R (dplyr, tidyr, ggplot2)',
      'Write complex analytical SQL queries (Window functions, CTEs, indexing)',
      'Publish an interactive Power BI portfolio dashboard showcasing business metrics'
    ],
    certifications: ['Microsoft Certified: Power BI Data Analyst Associate (PL-300)', 'Google Data Analytics Professional Certificate']
  },
  {
    title: 'Data Scientist & ML Engineer',
    category: 'Data Science',
    requiredSkills: ['Python', 'Machine Learning', 'Deep Learning', 'R', 'SQL', 'TensorFlow', 'PyTorch'],
    recommendedMinCgpa: 8.0,
    recommendedMinAptitude: 80,
    averageEntryLPA: '14.0 - 22.0 LPA',
    description: 'Constructs predictive statistical models, neural networks, and automated classification pipelines for enterprise automation.',
    learningPath: [
      'Master statistical inference, hypothesis testing, and regression analysis in R and Python',
      'Train and deploy machine learning models using Scikit-Learn, caret, and PyTorch',
      'Deploy end-to-end ML models as microservice endpoints with FastAPI or Plumber API'
    ],
    certifications: ['TensorFlow Developer Certificate', 'AWS Certified Machine Learning - Specialty']
  },
  {
    title: 'Full-Stack Web Developer',
    category: 'Web',
    requiredSkills: ['JavaScript', 'TypeScript', 'React', 'Node.js', 'SQL', 'Git', 'Tailwind'],
    recommendedMinCgpa: 7.0,
    recommendedMinAptitude: 70,
    averageEntryLPA: '6.5 - 16.0 LPA',
    description: 'Creates responsive, full-stack user interfaces and secure REST/GraphQL API backends for modern web applications.',
    learningPath: [
      'Build production full-stack React + Node/Express web apps with authentication',
      'Implement database schema design and relational queries with PostgreSQL/Prisma',
      'Deploy full-stack projects to Vercel, Docker containers, and Cloud platforms'
    ],
    certifications: ['Meta Front-End Developer Professional Certificate', 'OpenJS Node.js Application Developer (JSNAD)']
  },
  {
    title: 'Embedded Systems & IoT Engineer',
    category: 'Core Engineering',
    requiredSkills: ['C', 'C++', 'Embedded C', 'Microcontrollers', 'RTOS', 'MATLAB', 'IoT'],
    recommendedMinCgpa: 7.2,
    recommendedMinAptitude: 70,
    averageEntryLPA: '7.0 - 15.0 LPA',
    description: 'Develops low-level firmware, real-time operating system applications, and hardware-software communication drivers for semiconductor & automotive industries.',
    learningPath: [
      'Program ARM Cortex-M microcontrollers using Embedded C & bare-metal registers',
      'Interface sensor protocols (I2C, SPI, UART, CAN bus)',
      'Implement real-time task scheduling using FreeRTOS'
    ],
    certifications: ['Arm System-on-Chip Design Certification', 'Certified LabVIEW Associate Developer']
  },
  {
    title: 'Business Analyst & Tech Consultant',
    category: 'Business',
    requiredSkills: ['SQL', 'Excel', 'Power BI', 'Python', 'Communication', 'Data Analytics'],
    recommendedMinCgpa: 7.2,
    recommendedMinAptitude: 78,
    averageEntryLPA: '8.5 - 15.0 LPA',
    description: 'Bridges technical engineering teams with business stakeholders, assessing process workflows and financial impact.',
    learningPath: [
      'Hone case study problem solving, financial modeling, and guesstimates',
      'Sharpen corporate presentation and client consulting communication skills',
      'Master data story-telling through interactive visual reports'
    ],
    certifications: ['IIBA Entry Certificate in Business Analysis (ECBA)', 'McKinsey Forward Program']
  }
];

/**
 * Computes frequency and demand of technical skills across all students
 */
export function getInDemandSkillsAnalysis(students: Student[]) {
  const skillCounts: Record<string, { total: number; placed: number; avgSalary: number }> = {};
  const skillSalaries: Record<string, number[]> = {};

  students.forEach(student => {
    student.technicalSkills.forEach(skill => {
      if (!skillCounts[skill]) {
        skillCounts[skill] = { total: 0, placed: 0, avgSalary: 0 };
        skillSalaries[skill] = [];
      }
      skillCounts[skill].total++;
      if (student.placementStatus === 'Placed') {
        skillCounts[skill].placed++;
        if (student.salaryPackage > 0) {
          skillSalaries[skill].push(student.salaryPackage);
        }
      }
    });
  });

  return Object.keys(skillCounts)
    .map(skill => {
      const salList = skillSalaries[skill] || [];
      const avgSalary = salList.length > 0 
        ? Number((salList.reduce((a, b) => a + b, 0) / salList.length).toFixed(1)) 
        : 0;
      const placementRate = Number(((skillCounts[skill].placed / skillCounts[skill].total) * 100).toFixed(1));

      return {
        skill,
        studentCount: skillCounts[skill].total,
        placementRate,
        avgSalary,
        demandTier: avgSalary >= 14 ? 'High Value Tier' : avgSalary >= 8 ? 'Solid Demand' : 'Foundational'
      };
    })
    .sort((a, b) => b.studentCount - a.studentCount);
}

/**
 * Analyzes career pathway match for a given student or custom candidate profile
 */
export function evaluateCareerPaths(
  skills: string[],
  cgpa: number,
  aptitude: number,
  communication: number
): CareerPathRecommendation[] {
  const normalizedUserSkills = skills.map(s => s.toLowerCase().trim());

  return CAREER_ROLES.map(role => {
    const matchingSkills: string[] = [];
    const missingSkills: string[] = [];

    role.requiredSkills.forEach(req => {
      const match = normalizedUserSkills.some(userSkill => 
        userSkill.includes(req.toLowerCase()) || req.toLowerCase().includes(userSkill)
      );
      if (match) {
        matchingSkills.push(req);
      } else {
        missingSkills.push(req);
      }
    });

    const skillScore = (matchingSkills.length / role.requiredSkills.length) * 60;
    const cgpaScore = Math.min(1, cgpa / role.recommendedMinCgpa) * 20;
    const aptitudeScore = Math.min(1, aptitude / role.recommendedMinAptitude) * 20;

    const rawMatch = Math.round(skillScore + cgpaScore + aptitudeScore);
    const matchScore = Math.min(99, Math.max(15, rawMatch));

    let suitability: CareerPathRecommendation['suitability'] = 'Low';
    if (matchScore >= 75) {
      suitability = 'High';
    } else if (matchScore >= 50) {
      suitability = 'Medium';
    }

    const actionPlan = [
      ...missingSkills.slice(0, 2).map(skill => `Acquire practical expertise in ${skill} by completing a mini-project.`),
      ...role.learningPath.slice(0, 2)
    ];

    return {
      roleTitle: role.title,
      matchScore,
      suitability,
      requiredSkills: role.requiredSkills,
      matchingSkills,
      missingSkills,
      averageEntryLPA: role.averageEntryLPA,
      actionPlan
    };
  }).sort((a, b) => b.matchScore - a.matchScore);
}
